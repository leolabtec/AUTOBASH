#!/bin/bash
# =========================================
# Sing-box 节点管理脚本 v5.0
# 四层分离: 数据 / 协议 / 防火墙 / 系统
# =========================================
set -uo pipefail
ulimit -s 65536 2>/dev/null || true

readonly VER="5.0.2"
# 修复: 用 BASH_SOURCE[0] 而不是 $0
# 原因: 被 `bash -c 'source ...'` 调用时 $0="bash",定位会错;BASH_SOURCE 永远是当前文件路径
readonly SCRIPT=$(readlink -f "${BASH_SOURCE[0]}")

# ─── 加载 lib ────────────────────────────────────
# 查找顺序: 同目录 lib/、生产路径 /etc/sing-box/lib/
_find_lib_dir() {
    local self_dir; self_dir="$(dirname "$SCRIPT")"
    [[ -f "$self_dir/lib/common.sh" ]] && { echo "$self_dir/lib"; return; }
    [[ -f "/etc/sing-box/lib/common.sh" ]] && { echo "/etc/sing-box/lib"; return; }
    echo "" ; return 1
}
LIB_DIR=$(_find_lib_dir) || { echo "找不到 lib/ 目录(./lib 或 /etc/sing-box/lib)" >&2; exit 1; }
# shellcheck source=lib/common.sh
source "$LIB_DIR/common.sh"
source "$LIB_DIR/db.sh"
source "$LIB_DIR/ufw.sh"
source "$LIB_DIR/protocols.sh"
source "$LIB_DIR/system.sh"

DOMAIN="" IP=""

# ═════════════════════════════════════════════════
# 1. 节点管理
# ═════════════════════════════════════════════════

# 通用流程: 校验前置 → 收集参数 → db_set_strict(自动配置校验+回滚) → restart + ufw + render
# 节点是否存在(--argjson 用 string 比较 type)
_node_exists() { db_exists --arg t "$1" '.nodes[]|select(.type==$t)'; }

# 询问是否重建;返回 0=继续创建/重建,1=用户取消
_ask_rebuild() {
    local type="$1"
    if _node_exists "$type"; then
        warn "$(proto_display_name "$type") 已存在"
        confirm "重建?" || return 1
    fi
    return 0
}

# 原子替换节点:同一事务里删旧 + 加新,sing-box check 失败时整体回滚
# 同时清理旧节点的 UFW 端口(避免 stale 规则)
# 用法: _replace_node <type> <new-node-json>
_replace_node() {
    local type="$1" new_json="$2"
    # 先记下旧节点端口(用于回收 UFW),之后再事务化替换
    local old_port; old_port=$(db_read --arg t "$type" '.nodes[]?|select(.type==$t)|.port')
    db_update --arg t "$type" --argjson n "$new_json" \
        '.nodes |= (map(select(.type!=$t)) + [$n])' 1 || return 1
    # 旧端口和新端口不同时,显式 ufw_remove 旧端口避免 stale
    if [[ -n "$old_port" ]]; then
        local new_port; new_port=$(echo "$new_json" | jq -r .port)
        if [[ "$old_port" != "$new_port" ]]; then
            local proto
            for proto in $(node_ufw_protos "$type"); do
                ufw_remove "$old_port" "$proto"
            done
        fi
    fi
}

_node_post_create() {
    local type="$1"
    sys_restart_singbox || return 1
    ufw_sync_from_db
    render_node "$type"
}

create_trojan() {
    title "搭建 Trojan"
    [[ -f "$CERT/fullchain.pem" ]] || { err "先申请证书"; return 1; }
    _ask_rebuild trojan || return 0
    DOMAIN=$(get_domain)
    read_port "Trojan 端口(443 推荐用于 TLS 伪装)" tcp
    local port=$REPLY_PORT pw; pw=$(gp)
    sys_setup_fakeweb
    local node; node=$(jq -n --arg pw "$pw" --argjson p "$port" \
        '{type:"trojan",port:$p,password:$pw,extra:{}}')
    _replace_node trojan "$node" || { err "Trojan 创建失败"; return 1; }
    _node_post_create trojan
}

create_reality() {
    title "搭建 VLESS+Reality"
    _ask_rebuild vless-reality || return 0
    IP="${IP:-$(get_ip)}"
    read_port "VLESS+Reality 端口" tcp
    local port=$REPLY_PORT
    echo "伪装: 1.microsoft  2.apple  3.amazon  4.cloudflare"
    local c; read -rp "选择: " c
    local sn; case "${c:-1}" in
        2) sn="www.apple.com" ;; 3) sn="www.amazon.com" ;;
        4) sn="www.cloudflare.com" ;; *) sn="www.microsoft.com" ;;
    esac
    local kp pk pub uuid sid
    kp=$(sing-box generate reality-keypair)
    pk=$(echo "$kp"  | grep PrivateKey | awk '{print $2}')
    pub=$(echo "$kp" | grep PublicKey  | awk '{print $2}')
    uuid=$(gu); sid=$(openssl rand -hex 8)
    local extra; extra=$(jq -n --arg pk "$pk" --arg pub "$pub" --arg sid "$sid" --arg sn "$sn" \
        '{private_key:$pk,public_key:$pub,short_id:$sid,server_name:$sn}')
    local node; node=$(jq -n --arg u "$uuid" --argjson p "$port" --argjson e "$extra" \
        '{type:"vless-reality",port:$p,password:"",uuid:$u,extra:$e}')
    _replace_node vless-reality "$node" || { err "VLESS+Reality 创建失败"; return 1; }
    _node_post_create vless-reality
}

create_hy2() {
    title "搭建 Hysteria2"
    [[ -f "$CERT/fullchain.pem" ]] || { err "先申请证书"; return 1; }
    _ask_rebuild hysteria2 || return 0
    DOMAIN=$(get_domain)
    read_port "Hysteria2 端口(UDP)" udp
    local port=$REPLY_PORT pw; pw=$(gp)
    local node; node=$(jq -n --arg pw "$pw" --argjson p "$port" \
        '{type:"hysteria2",port:$p,password:$pw,extra:{}}')
    _replace_node hysteria2 "$node" || { err "Hysteria2 创建失败"; return 1; }
    _node_post_create hysteria2
}

create_tuic() {
    title "搭建 TUIC v5"
    [[ -f "$CERT/fullchain.pem" ]] || { err "先申请证书"; return 1; }
    _ask_rebuild tuic || return 0
    DOMAIN=$(get_domain)
    read_port "TUIC 端口(UDP)" udp
    local port=$REPLY_PORT uuid pw cc
    uuid=$(gu); pw=$(gp)
    echo "拥塞: 1.BBR  2.Cubic  3.NewReno"
    local c; read -rp "选择: " c
    case "${c:-1}" in 2) cc="cubic" ;; 3) cc="new_reno" ;; *) cc="bbr" ;; esac
    local node; node=$(jq -n --arg u "$uuid" --arg pw "$pw" --argjson p "$port" --arg cc "$cc" \
        '{type:"tuic",port:$p,password:$pw,uuid:$u,extra:{congestion_control:$cc}}')
    _replace_node tuic "$node" || { err "TUIC 创建失败"; return 1; }
    _node_post_create tuic
}

create_ss() {
    title "搭建 Shadowsocks"
    _ask_rebuild shadowsocks || return 0
    IP="${IP:-$(get_ip)}"
    read_port "SS 端口" both
    local port=$REPLY_PORT
    echo "加密: 1.2022-blake3-128(推荐)  2.2022-blake3-256  3.aes-256-gcm  4.chacha20"
    local c; read -rp "选择: " c
    local m p
    case "${c:-1}" in
        1) m="2022-blake3-aes-128-gcm"; p=$(gp_ss_key "$m") ;;
        2) m="2022-blake3-aes-256-gcm"; p=$(gp_ss_key "$m") ;;
        3) m="aes-256-gcm";             p=$(gp 32) ;;
        4) m="chacha20-ietf-poly1305";  p=$(gp 32) ;;
        *) m="2022-blake3-aes-128-gcm"; p=$(gp_ss_key "$m") ;;
    esac
    local node; node=$(jq -n --arg pw "$p" --argjson po "$port" --arg m "$m" \
        '{type:"shadowsocks",port:$po,password:$pw,extra:{method:$m}}')
    _replace_node shadowsocks "$node" || { err "SS 创建失败"; return 1; }
    _node_post_create shadowsocks
}

create_snell() {
    title "搭建 Snell v5"
    _ask_rebuild snell || return 0
    local a; a=$(uname -m); [[ "$a" == "x86_64" ]] && a="amd64" || a="aarch64"
    curl -fsSL "https://dl.nssurge.com/snell/snell-server-v5.0.1-linux-${a}.zip" -o /tmp/snell.zip
    unzip -o /tmp/snell.zip -d /tmp/snell/ 2>/dev/null
    cp /tmp/snell/snell-server "$SNELL_BIN"; chmod +x "$SNELL_BIN"
    rm -rf /tmp/snell*
    read_port "Snell 端口" tcp
    local port=$REPLY_PORT psk; psk=$(openssl rand -base64 32)
    echo "混淆: 1.HTTP  2.TLS  3.关闭"
    local c; read -rp "选择: " c
    local obfs; case "${c:-1}" in 2) obfs="tls" ;; 3) obfs="off" ;; *) obfs="http" ;; esac
    mkdir -p /etc/snell
    printf "[snell-server]\nlisten = :::%s\npsk = %s\nipv6 = true\nobfs = %s\n" "$port" "$psk" "$obfs" > "$SNELL_CFG"
    sys_setup_snell_service
    systemctl restart snell
    if systemctl is-active --quiet snell; then
        # Snell 不参与 sing-box config,无需 sing-box check
        local node; node=$(jq -n --arg pw "$psk" --argjson p "$port" --arg ob "$obfs" \
            '{type:"snell",port:$p,password:$pw,extra:{obfs:$ob}}')
        db_update --argjson n "$node" '.nodes |= (map(select(.type!="snell")) + [$n])' 0
        ufw_sync_from_db
        ok "Snell OK"
        IP="${IP:-$(get_ip)}"
        render_node snell
    else
        err "Snell 启动失败"
    fi
}

create_shadowtls() {
    title "搭建 ShadowTLS v3 + Shadowsocks"
    _ask_rebuild shadowtls || return 0
    IP="${IP:-$(get_ip)}"
    read_port "ShadowTLS 端口" tcp
    local port=$REPLY_PORT
    echo "握手伪装: 1.microsoft  2.apple  3.amazon  4.cloudflare"
    local hc; read -rp "选择: " hc
    local hs; case "${hc:-1}" in
        2) hs="www.apple.com" ;; 3) hs="www.amazon.com" ;;
        4) hs="www.cloudflare.com" ;; *) hs="www.microsoft.com" ;;
    esac
    local stls_pass ss_pass ss_method
    stls_pass=$(gp)
    ss_method="2022-blake3-aes-128-gcm"
    ss_pass=$(gp_ss_key "$ss_method")
    local extra; extra=$(jq -n --arg hs "$hs" --arg sp "$ss_pass" --arg sm "$ss_method" --arg stp "$stls_pass" \
        '{handshake_server:$hs, ss_password:$sp, ss_method:$sm, stls_password:$stp}')
    local node; node=$(jq -n --arg pw "$stls_pass" --argjson p "$port" --argjson e "$extra" \
        '{type:"shadowtls",port:$p,password:$pw,extra:$e}')
    _replace_node shadowtls "$node" || { err "ShadowTLS 创建失败"; return 1; }
    _node_post_create shadowtls
}

create_anytls() {
    title "搭建 AnyTLS"
    [[ -f "$CERT/fullchain.pem" ]] || { err "先申请证书"; return 1; }
    _ask_rebuild anytls || return 0
    DOMAIN=$(get_domain)
    read_port "AnyTLS 端口" tcp
    local port=$REPLY_PORT pw; pw=$(gp)
    local extra; extra=$(jq -n '{padding:true}')
    local node; node=$(jq -n --arg pw "$pw" --argjson p "$port" --argjson e "$extra" \
        '{type:"anytls",port:$p,password:$pw,extra:$e}')
    _replace_node anytls "$node" || { err "AnyTLS 创建失败"; return 1; }
    _node_post_create anytls
}

delete_node() {
    local idx=0 types=() n
    while IFS= read -r n; do
        [[ -z "$n" ]] && continue
        ((idx++)) || true
        local t; t=$(echo "$n" | jq -r .type)
        types+=("$t")
        echo "  $idx. $(proto_display_name "$t") :$(echo "$n" | jq -r .port)"
    done < <(db_read_c '.nodes[]?')
    [[ $idx -eq 0 ]] && { warn "无节点"; return 0; }
    local d; read -rp "删除: " d
    [[ "$d" =~ ^[0-9]+$ && "$d" -ge 1 && "$d" -le $idx ]] || return 0
    local tp="${types[$((d-1))]}"
    confirm "删除 $(proto_display_name "$tp")?" || return 0
    # 先记下端口,稍后回收 UFW
    local old_port; old_port=$(db_read --arg t "$tp" '.nodes[]?|select(.type==$t)|.port')
    # Snell 特例:停服务
    [[ "$tp" == "snell" ]] && sys_stop_snell
    db_update --arg tp "$tp" \
        '.nodes |= map(select(.type!=$tp)) | .users |= map(select(.protocol!=$tp))' \
        1 || { err "删除失败(配置校验未通过)"; return 1; }
    sys_restart_singbox
    # 显式回收该节点的 UFW 端口
    if [[ -n "$old_port" ]]; then
        local proto
        for proto in $(node_ufw_protos "$tp"); do
            ufw_remove "$old_port" "$proto"
        done
    fi
    ufw_sync_from_db
    ok "已删除"
}

node_menu() {
    while true; do
        title "1. 节点管理"
        echo "  1.证书     2.Trojan        3.VLESS+Reality  4.Hysteria2"
        echo "  5.TUIC     6.Shadowsocks   7.Snell          8.ShadowTLS"
        echo "  9.AnyTLS  10.查看节点     11.删除节点       0.返回"
        local c; read -rp "选择: " c
        case "$c" in
            1)  sys_issue_cert ;;
            2)  create_trojan ;;
            3)  create_reality ;;
            4)  create_hy2 ;;
            5)  create_tuic ;;
            6)  create_ss ;;
            7)  create_snell ;;
            8)  create_shadowtls ;;
            9)  create_anytls ;;
            10) DOMAIN="${DOMAIN:-$(get_domain)}"; IP="${IP:-$(get_ip)}"
                local t
                while IFS= read -r t; do
                    [[ -z "$t" ]] && continue
                    render_node "$t"
                done < <(db_read '.nodes[]?.type') ;;
            11) delete_node ;;
            0)  return ;;
        esac
        pause
    done
}

# ═════════════════════════════════════════════════
# 2. 入站管理(用户组 + 用户)
# ═════════════════════════════════════════════════

inbound_menu() {
    while true; do
        title "2. 入站管理"
        local gc uc
        gc=$(db_read '.user_groups | length // 0')
        uc=$(db_read '.users | length // 0')
        info "用户组: $gc  用户: $uc"
        echo "  1.创建组  2.删除组  3.创建用户  4.删除用户"
        echo "  5.用户列表  6.查看用户链接  0.返回"
        local c; read -rp "选择: " c
        case "$c" in
            1)  inbound_create_group ;;
            2)  inbound_delete_group ;;
            3)  inbound_create_user ;;
            4)  inbound_delete_user ;;
            5)  inbound_list_users ;;
            6)  inbound_view_user ;;
            0)  return ;;
        esac
        pause
    done
}

inbound_create_group() {
    local name desc
    read -rp "组名: " name; [[ -z "$name" ]] && return 0
    db_exists --arg n "$name" '.user_groups[]|select(.name==$n)' \
        && { warn "组 $name 已存在"; return 0; }
    read -rp "描述: " desc
    db_update ".user_groups += [$(jq -n --arg n "$name" --arg d "$desc" \
        '{name:$n,description:$d}')]" 0
    ok "组 $name 已创建"
}

inbound_delete_group() {
    local idx=0 names=() g
    while IFS= read -r g; do
        [[ -z "$g" ]] && continue
        ((idx++)) || true
        local n; n=$(echo "$g" | jq -r .name)
        names+=("$n")
        echo "  $idx. $n ($(echo "$g" | jq -r .description))"
    done < <(db_read_c '.user_groups[]?')
    [[ $idx -eq 0 ]] && { warn "无组"; return 0; }
    local d; read -rp "删除: " d
    [[ "$d" =~ ^[0-9]+$ && "$d" -ge 1 && "$d" -le $idx ]] || return 0
    local gn="${names[$((d-1))]}"
    confirm "删除 $gn?" || return 0
    db_update --arg g "$gn" \
        '.user_groups |= map(select(.name!=$g)) | .users |= map(if .group==$g then .group="" else . end) | .routes |= map(select(.group!=$g))' \
        1 || return 1
    sys_restart_singbox
    ok "已删除组 $gn"
}

inbound_create_user() {
    # 选协议
    local idx=0 types=() n
    while IFS= read -r n; do
        [[ -z "$n" ]] && continue
        ((idx++)) || true
        local t; t=$(echo "$n" | jq -r .type)
        types+=("$t")
        echo "  $idx. $(proto_display_name "$t")"
    done < <(db_read_c '.nodes[]?')
    [[ $idx -eq 0 ]] && { warn "先搭建节点"; return 0; }
    local pc; read -rp "选择协议: " pc
    [[ "$pc" =~ ^[0-9]+$ && "$pc" -ge 1 && "$pc" -le $idx ]] || return 0
    local proto="${types[$((pc-1))]}"

    proto_supports_multiuser "$proto" || {
        warn "$(proto_display_name "$proto") 不支持多用户"
        case "$proto" in
            vless-reality) info "VLESS 无 name 字段不支持 auth_user 分流" ;;
            snell)         info "Snell 单 PSK,不支持多用户" ;;
            shadowsocks)   info "传统 SS 不支持多用户,需 2022-blake3-* 加密" ;;
        esac
        return 0
    }

    local uname; read -rp "用户名: " uname; [[ -z "$uname" ]] && return 0
    db_exists --arg n "$uname" '.users[]|select(.name==$n)' \
        && { warn "用户 $uname 已存在"; return 0; }

    # 选用户组
    local group="" gi=0 gnames=("(不分组)") g
    while IFS= read -r g; do
        [[ -z "$g" ]] && continue
        ((gi++)) || true
        gnames+=("$(echo "$g" | jq -r .name)")
        echo "  $gi. $(echo "$g" | jq -r .name)"
    done < <(db_read_c '.user_groups[]?')
    echo "  0. 不分组"
    local gc; read -rp "选择组: " gc
    [[ "$gc" =~ ^[0-9]+$ && "$gc" -ge 1 && "$gc" -le $gi ]] && group="${gnames[$gc]}"

    # 生成凭证(SS 按 method 选密钥长度)
    local user_json pw uuid_v
    case "$proto" in
        trojan|hysteria2|shadowtls|anytls)
            pw=$(gp)
            user_json=$(jq -n --arg n "$uname" --arg p "$proto" --arg pw "$pw" --arg g "$group" \
                '{name:$n,protocol:$p,password:$pw,group:$g}') ;;
        tuic)
            uuid_v=$(gu); pw=$(gp)
            user_json=$(jq -n --arg n "$uname" --arg p "$proto" --arg u "$uuid_v" --arg pw "$pw" --arg g "$group" \
                '{name:$n,protocol:$p,uuid:$u,password:$pw,group:$g}') ;;
        shadowsocks)
            # 按节点 method 决定密钥长度
            local m; m=$(db_read '.nodes[]?|select(.type=="shadowsocks")|.extra.method' | head -1)
            pw=$(gp_ss_key "$m")
            user_json=$(jq -n --arg n "$uname" --arg p "$proto" --arg pw "$pw" --arg g "$group" \
                '{name:$n,protocol:$p,password:$pw,group:$g}') ;;
    esac

    db_update --argjson u "$user_json" '.users += [$u]' 1 \
        || { err "用户创建失败"; return 1; }
    sys_restart_singbox
    ok "用户 $uname 已创建(协议:$proto 组:${group:-无})"
    render_user "$uname"
}

inbound_delete_user() {
    local idx=0 unames=() u
    while IFS= read -r u; do
        [[ -z "$u" ]] && continue
        ((idx++)) || true
        local n; n=$(echo "$u" | jq -r .name)
        unames+=("$n")
        echo "  $idx. $n [$(echo "$u" | jq -r .protocol)] 组:$(echo "$u" | jq -r '.group // "无"')"
    done < <(db_read_c '.users[]?')
    [[ $idx -eq 0 ]] && { warn "无用户"; return 0; }
    local d; read -rp "删除: " d
    [[ "$d" =~ ^[0-9]+$ && "$d" -ge 1 && "$d" -le $idx ]] || return 0
    local un="${unames[$((d-1))]}"
    confirm "删除 $un?" || return 0
    db_update --arg n "$un" '.users |= map(select(.name!=$n))' 1 || return 1
    sys_restart_singbox
    ok "已删除"
}

inbound_list_users() {
    title "用户列表"
    echo -e "${W}[未分组] → direct${N}"
    local u
    while IFS= read -r u; do
        [[ -z "$u" ]] && continue
        echo "  $(echo "$u" | jq -r .name) [$(echo "$u" | jq -r .protocol)]"
    done < <(db_read_c '.users[]?|select(.group=="" or .group==null)')

    local g
    while IFS= read -r g; do
        [[ -z "$g" ]] && continue
        local gn; gn=$(echo "$g" | jq -r .name)
        local out; out=$(db_read --arg g "$gn" '.routes[]?|select(.group==$g)|.outbound')
        [[ -z "$out" ]] && out="direct"
        echo -e "\n${W}[$gn] → $out${N}"
        while IFS= read -r u; do
            [[ -z "$u" ]] && continue
            echo "  $(echo "$u" | jq -r .name) [$(echo "$u" | jq -r .protocol)]"
        done < <(db_read_c --arg g "$gn" '.users[]?|select(.group==$g)')
    done < <(db_read_c '.user_groups[]?')
}

inbound_view_user() {
    local idx=0 unames=() u
    while IFS= read -r u; do
        [[ -z "$u" ]] && continue
        ((idx++)) || true
        local n; n=$(echo "$u" | jq -r .name)
        unames+=("$n")
        echo "  $idx. $n [$(echo "$u" | jq -r .protocol)] 组:$(echo "$u" | jq -r '.group // "无"')"
    done < <(db_read_c '.users[]?')
    [[ $idx -eq 0 ]] && { warn "无用户"; return 0; }
    local d; read -rp "选择: " d
    [[ "$d" =~ ^[0-9]+$ && "$d" -ge 1 && "$d" -le $idx ]] || return 0
    render_user "${unames[$((d-1))]}"
}

# ═════════════════════════════════════════════════
# 3. 出站管理
# ═════════════════════════════════════════════════

outbound_menu() {
    while true; do
        title "3. 出站管理"
        local idx=0 tags=() n
        while IFS= read -r n; do
            [[ -z "$n" ]] && continue
            ((idx++)) || true
            local t tp s p used_by
            t=$(echo "$n"  | jq -r .tag)
            tp=$(echo "$n" | jq -r .type)
            s=$(echo "$n"  | jq -r .server)
            p=$(echo "$n"  | jq -r .server_port)
            tags+=("$t")
            used_by=$(db_read --arg o "$t" '[.routes[]?|select(.outbound==$o)|.group] | join(",")')
            echo "  $idx. [$tp] $t → ${s}:${p} ${used_by:+(路由: $used_by)}"
        done < <(db_read_c '.outbounds[]?')
        [[ $idx -eq 0 ]] && info "(无出站代理)"
        echo "  1.导入(交互)  2.导入(链接)  3.删除  4.测试  0.返回"
        local c; read -rp "选择: " c
        case "$c" in
            1) outbound_import_cli ;;
            2) outbound_import_link ;;
            3) [[ $idx -gt 0 ]] && {
                local d; read -rp "删除[1-$idx]: " d
                [[ "$d" =~ ^[0-9]+$ && "$d" -ge 1 && "$d" -le $idx ]] && {
                    local tg="${tags[$((d-1))]}"
                    confirm "删除 $tg?" && {
                        db_update --arg tg "$tg" \
                            '.outbounds |= map(select(.tag!=$tg)) | .routes |= map(select(.outbound!=$tg))' 1 \
                            && sys_restart_singbox && ok "已删除"
                    }
                }
            } ;;
            4) local n
               while IFS= read -r n; do
                   [[ -z "$n" ]] && continue
                   local tg; tg=$(echo "$n" | jq -r .tag)
                   test_outbound "$n" && ok "  $tg: 通" || err "  $tg: 不通"
               done < <(db_read_c '.outbounds[]?') ;;
            0) return ;;
        esac
        pause
    done
}

outbound_import_cli() {
    echo "  1.SOCKS5  2.HTTP  3.SS"
    local tc; read -rp "类型: " tc
    local type; case "$tc" in 1) type="socks" ;; 2) type="http" ;; 3) type="shadowsocks" ;; *) return ;; esac
    local s p u="" pw="" m=""
    read -rp "服务器: " s; [[ -z "$s" ]] && return
    read -rp "端口: " p
    if [[ "$type" != "shadowsocks" ]]; then
        read -rp "用户名(可选): " u
        [[ -n "$u" ]] && read -rsp "密码: " pw && echo
    else
        echo "加密: 1.aes-256  2.aes-128  3.chacha20  4.2022-blake3-128"
        local mc; read -rp "选择: " mc
        case "${mc:-1}" in
            1) m="aes-256-gcm" ;; 2) m="aes-128-gcm" ;;
            3) m="chacha20-ietf-poly1305" ;; 4) m="2022-blake3-aes-128-gcm" ;;
        esac
        read -rsp "密码: " pw; echo
    fi
    local sanitized; sanitized=$(echo "$s" | tr '.:' '__')
    local tag="${type}-${sanitized}"
    db_exists --arg t "$tag" '.outbounds[]|select(.tag==$t)' && tag="${tag}_${p}"
    local ob
    case "$type" in
        socks) ob=$(jq -n --arg t "$tag" --arg s "$s" --argjson p "$p" --arg u "$u" --arg pw "$pw" \
            '{type:"socks",tag:$t,server:$s,server_port:$p} + (if $u!="" then {username:$u,password:$pw} else {} end)') ;;
        http)  ob=$(jq -n --arg t "$tag" --arg s "$s" --argjson p "$p" --arg u "$u" --arg pw "$pw" \
            '{type:"http",tag:$t,server:$s,server_port:$p} + (if $u!="" then {username:$u,password:$pw} else {} end)') ;;
        shadowsocks) ob=$(jq -n --arg t "$tag" --arg s "$s" --argjson p "$p" --arg m "$m" --arg pw "$pw" \
            '{type:"shadowsocks",tag:$t,server:$s,server_port:$p,method:$m,password:$pw}') ;;
    esac
    _outbound_save_or_force "$ob"
}

outbound_import_link() {
    local link; read -rp "链接: " link; [[ -z "$link" ]] && return
    local ob; ob=$(parse_link "$link") || { err "解析失败"; return 1; }
    echo "$ob" | jq '{type,tag,server,server_port}'
    _outbound_save_or_force "$ob"
}

_outbound_save_or_force() {
    local ob="$1"
    info "测试..."
    if test_outbound "$ob"; then
        ok "连通"
        db_update --argjson o "$ob" '.outbounds += [$o]' 1 \
            && sys_restart_singbox && ok "保存"
    else
        err "不通"
        confirm "强制保存?" && {
            db_update --argjson o "$ob" '.outbounds += [$o]' 1 && sys_restart_singbox
        }
    fi
}

# ═════════════════════════════════════════════════
# 4. 路由规则
# ═════════════════════════════════════════════════

route_menu() {
    while true; do
        title "4. 路由规则"
        info "节点直连 = direct | 用户走组 → 组走出站"
        echo -e "${W}当前路由映射:${N}"
        local has=false r
        while IFS= read -r r; do
            [[ -z "$r" ]] && continue
            has=true
            local g o uc
            g=$(echo "$r" | jq -r .group)
            o=$(echo "$r" | jq -r .outbound)
            uc=$(db_read --arg g "$g" '[.users[]?|select(.group==$g)] | length')
            echo "  组[$g] → $o ($uc 人)"
        done < <(db_read_c '.routes[]?')
        [[ "$has" == "false" ]] && echo "  (无路由,所有用户走 direct)"
        echo "  1.设置路由  2.删除路由  0.返回"
        local c; read -rp "选择: " c
        case "$c" in
            1) route_set ;;
            2) route_delete ;;
            0) return ;;
        esac
        pause
    done
}

route_set() {
    local gi=0 gnames=() g
    while IFS= read -r g; do
        [[ -z "$g" ]] && continue
        ((gi++)) || true
        gnames+=("$(echo "$g" | jq -r .name)")
        echo "  $gi. $(echo "$g" | jq -r .name)"
    done < <(db_read_c '.user_groups[]?')
    [[ $gi -eq 0 ]] && { warn "先创建用户组"; return 0; }
    local gc; read -rp "选择组: " gc
    [[ "$gc" =~ ^[0-9]+$ && "$gc" -ge 1 && "$gc" -le $gi ]] || return 0
    local gn="${gnames[$((gc-1))]}"

    local oi=0 otags=() n
    while IFS= read -r n; do
        [[ -z "$n" ]] && continue
        ((oi++)) || true
        otags+=("$(echo "$n" | jq -r .tag)")
        echo "  $oi. $(echo "$n" | jq -r .tag)"
    done < <(db_read_c '.outbounds[]?')
    [[ $oi -eq 0 ]] && { warn "先导入出站"; return 0; }
    local oc; read -rp "选择出站: " oc
    [[ "$oc" =~ ^[0-9]+$ && "$oc" -ge 1 && "$oc" -le $oi ]] || return 0
    local otag="${otags[$((oc-1))]}"

    db_update --arg g "$gn" --arg o "$otag" \
        '.routes |= (map(select(.group!=$g)) + [{group:$g,outbound:$o}])' 1 \
        && sys_restart_singbox && ok "路由: 组[$gn] → $otag"
}

route_delete() {
    local ri=0 rgroups=() r
    while IFS= read -r r; do
        [[ -z "$r" ]] && continue
        ((ri++)) || true
        local g; g=$(echo "$r" | jq -r .group)
        rgroups+=("$g")
        echo "  $ri. $g → $(echo "$r" | jq -r .outbound)"
    done < <(db_read_c '.routes[]?')
    [[ $ri -eq 0 ]] && { warn "无路由"; return 0; }
    local d; read -rp "删除: " d
    [[ "$d" =~ ^[0-9]+$ && "$d" -ge 1 && "$d" -le $ri ]] || return 0
    db_update --arg g "${rgroups[$((d-1))]}" '.routes |= map(select(.group!=$g))' 1 \
        && sys_restart_singbox && ok "已删除"
}

# ═════════════════════════════════════════════════
# 5. 系统设置
# ═════════════════════════════════════════════════

sys_menu() {
    while true; do
        title "5. 系统设置"
        echo "  1.状态  2.TG Bot  3.安全加固  4.BBR  5.更新 sing-box  6.快捷键  0.返回"
        local c; read -rp "选择: " c
        case "$c" in
            1) sys_show_status ;;
            2) config_tgbot ;;
            3) security_menu ;;
            4) sys_enable_bbr ;;
            5) sys_update_singbox ;;
            6) local k; read -rp "快捷键[当前:$(cat "$CFG/shortcut.conf" 2>/dev/null || echo s)]: " k
               [[ -n "$k" ]] && sys_install_shortcut "$k" "$SCRIPT" ;;
            0) return ;;
        esac
        pause
    done
}

sys_show_status() {
    title "状态"
    systemctl is-active --quiet sing-box && ok "sing-box: 运行" || err "sing-box: 停止"
    systemctl is-active --quiet snell    2>/dev/null && ok "snell: 运行"
    systemctl is-active --quiet fakeweb  2>/dev/null && ok "伪装站: 运行"
    systemctl is-active --quiet singbox-tgbot 2>/dev/null && ok "TG Bot: 运行"
    [[ -f "$CERT/fullchain.pem" ]] && info "证书: $(get_domain)"
    info "节点: $(db_read '.nodes|length')  用户: $(db_read '.users|length')  组: $(db_read '.user_groups|length')  出站: $(db_read '.outbounds|length')  路由: $(db_read '.routes|length')"
    info "IP: ${IP:-$(get_ip)}  BBR: $(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null)"
    echo
    info "端口:"
    ss -tulnp 2>/dev/null | grep sing-box
}

# TG bot 配置(完整流程)
config_tgbot() {
    title "TG Bot"
    local en; en=$(db_read '.tgbot.enabled')
    if [[ "$en" == "true" ]]; then
        local cur_bot; cur_bot=$(db_read '.tgbot.bot_token')
        info "已启用 (Token: ${cur_bot:0:10}...)"
        echo "  1.重新配置  2.停止  3.重启  0.返回"
        local c; read -rp "选择: " c
        case "$c" in
            2) sys_tgbot_stop; return ;;
            3) sys_tgbot_restart; return ;;
            0) return ;;
        esac
    fi
    info "步骤 1: 在 Telegram 找 @BotFather → /newbot → 获取 Token"
    local token; read -rp "Bot Token: " token; [[ -z "$token" ]] && return
    local bot_info; bot_info=$(curl -s "https://api.telegram.org/bot${token}/getMe")
    echo "$bot_info" | jq -e '.ok==true' >/dev/null 2>&1 || { err "Token 无效"; return; }
    local bot_name; bot_name=$(echo "$bot_info" | jq -r .result.username)
    ok "Bot 验证成功: @$bot_name"

    info "步骤 2: 在 Telegram 向 @$bot_name 发送任意消息,然后按回车"
    read -rp "" -n1; echo
    local updates cids
    updates=$(curl -s "https://api.telegram.org/bot${token}/getUpdates?limit=10")
    cids=$(echo "$updates" | jq -r '[.result[].message.chat.id // empty] | unique | map(select(.!=null)) | .[]')
    if [[ -z "$cids" ]]; then
        warn "未检测到消息"
        read -rp "手动输入 Chat ID: " cids; [[ -z "$cids" ]] && return
    else
        info "检测到 Chat ID: $cids"
        confirm "使用此 ID?" || { read -rp "手动输入: " cids; }
    fi
    local ids; ids=$(echo "$cids" | jq -R -s 'split("\n") | map(select(.!="") | tonumber)')
    db_update --arg tk "$token" --argjson ids "$ids" \
        '.tgbot = {enabled:true,bot_token:$tk,chat_ids:$ids}' 0

    # 修复 P0-F: 先 deleteWebhook 防止 token 复用场景 getUpdates 永远空
    curl -s "https://api.telegram.org/bot${token}/deleteWebhook?drop_pending_updates=true" >/dev/null 2>&1

    info "步骤 3: 注册 Bot 命令菜单..."
    # 修复 P0-A: 只注册 bot 实际实现的 8 条命令,避免点了没响应误导用户
    curl -s -X POST "https://api.telegram.org/bot${token}/setMyCommands" \
        -H "Content-Type: application/json" \
        -d '{"commands":[
            {"command":"status","description":"系统状态"},
            {"command":"nodes","description":"节点列表"},
            {"command":"users","description":"用户列表(按组)"},
            {"command":"link","description":"用户链接: /link 名"},
            {"command":"security","description":"安全状态"},
            {"command":"ban","description":"封禁IP列表"},
            {"command":"unban","description":"解封: /unban IP"},
            {"command":"ufw","description":"UFW 规则"},
            {"command":"restart","description":"重启 sing-box"},
            {"command":"help","description":"帮助"}
        ]}' >/dev/null 2>&1
    ok "Bot 菜单已设置(10 条只读 + restart 命令)"

    # 生成 bot 子脚本(详见 tgbot_template)
    sys_generate_tgbot_script "$token"
    cat > /etc/systemd/system/singbox-tgbot.service <<EOF
[Unit]
Description=Sing-box TG Bot
After=network.target

[Service]
ExecStart=/bin/bash $TGBOT
Restart=on-failure
RestartSec=30
# 修复 P0-H: systemd 默认不传 HOME,common.sh 引用 \$HOME 会触发 set -u 挂掉
Environment=PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
Environment=HOME=/root

[Install]
WantedBy=multi-user.target
EOF
    sys_tgbot_start
    info "在 Telegram 点击 @$bot_name 的菜单按钮即可看到命令列表"
}

# 生成 TG bot 子脚本(读 .enabled、OFFSET 持久化)
sys_generate_tgbot_script() {
    local token="$1"
    mkdir -p "$TGBOT_STATE_DIR"
    cat > "$TGBOT" <<TGEOF
#!/bin/bash
# Auto-generated by singbox-manager v$VER
set -u
BOT_TOKEN="$token"
LIB_DIR="$LIB_DIR"
OFFSET_FILE="$TGBOT_STATE_DIR/offset"

source "\$LIB_DIR/common.sh"
source "\$LIB_DIR/db.sh"
source "\$LIB_DIR/protocols.sh"

[[ -f "\$OFFSET_FILE" ]] && OFFSET=\$(cat "\$OFFSET_FILE") || OFFSET=0
save_offset() { echo "\$1" > "\$OFFSET_FILE"; }

# 修复 P0-J: 改用 HTML parse_mode (Markdown legacy 对组名/用户名/URL 含 _*[]() 时静默 400)
# HTML 只需转义 < > & 三个字符,容错远好于 Markdown
# 修复反模式 silent-swallow-on-network-boundary: 失败时 logger 到 journal,而不是 >/dev/null 2>&1
send() {
    local resp
    resp=\$(curl -s -X POST "https://api.telegram.org/bot\$BOT_TOKEN/sendMessage" \\
        --data-urlencode "chat_id=\$1" --data-urlencode "text=\$2" \\
        --data-urlencode "parse_mode=HTML" 2>&1)
    if ! echo "\$resp" | jq -e '.ok==true' >/dev/null 2>&1; then
        # 截断防止 logger 拒收超长消息;Telegram 错误信息通常 < 300 字符
        logger -t singbox-tgbot "send to chat \$1 FAILED: \$(echo "\$resp" | tr -d '\\n' | head -c 300)"
    fi
}

# HTML 转义:任何变量值进消息前都过这个函数
he() {
    local s="\$1"
    s="\${s//&/&amp;}"   # & 必须最先
    s="\${s//</&lt;}"
    s="\${s//>/&gt;}"
    printf '%s' "\$s"
}

# 检查 .enabled,false 时进入轮询等待(修复 Q-1)
is_enabled() { [[ "\$(db_read '.tgbot.enabled')" == "true" ]]; }

cmd_status() {
    local nc uc gc oc cert ip bbr sb
    sb=\$(systemctl is-active sing-box 2>/dev/null)
    nc=\$(db_read '.nodes|length'); uc=\$(db_read '.users|length')
    gc=\$(db_read '.user_groups|length'); oc=\$(db_read '.outbounds|length')
    cert="无"; [[ -f "\$CERT/fullchain.pem" ]] && cert="\$(get_domain) \$(openssl x509 -in "\$CERT/fullchain.pem" -noout -enddate 2>/dev/null|sed 's/notAfter=//')"
    ip=\$(get_ip); bbr=\$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null)
    send "\$1" "<b>系统状态</b>
sing-box: \$(he "\$sb")
节点: \$nc | 用户: \$uc | 组: \$gc | 出站: \$oc
证书: \$(he "\$cert")
IP: \$(he "\$ip")
BBR: \$(he "\$bbr")"
}

cmd_nodes() {
    local msg="<b>节点列表</b>"\$'\n' n
    while IFS= read -r n; do
        [[ -z "\$n" ]] && continue
        msg+="• \$(he "\$(echo "\$n"|jq -r .type)") :\$(echo "\$n"|jq -r .port)"\$'\n'
    done < <(db_read_c '.nodes[]?')
    [[ "\$msg" == *"•"* ]] || msg+="(无)"
    send "\$1" "\$msg"
}

cmd_users() {
    local msg="<b>用户列表</b>"
    local u g gn out has_any=0 ungrouped_lines="" group_lines=""
    while IFS= read -r u; do
        [[ -z "\$u" ]] && continue
        has_any=1
        ungrouped_lines+=\$'\n'"  \$(he "\$(echo "\$u"|jq -r .name)") [\$(he "\$(echo "\$u"|jq -r .protocol)")]"
    done < <(db_read_c '.users[]?|select(.group=="" or .group==null)')
    [[ -n "\$ungrouped_lines" ]] && msg+=\$'\n'"<i>未分组 → direct:</i>\$ungrouped_lines"
    while IFS= read -r g; do
        [[ -z "\$g" ]] && continue
        gn=\$(echo "\$g"|jq -r .name)
        out=\$(db_read --arg g "\$gn" '.routes[]?|select(.group==\$g)|.outbound')
        [[ -z "\$out" ]] && out="direct"
        group_lines=""
        while IFS= read -r u; do
            [[ -z "\$u" ]] && continue
            has_any=1
            group_lines+=\$'\n'"  \$(he "\$(echo "\$u"|jq -r .name)") [\$(he "\$(echo "\$u"|jq -r .protocol)")]"
        done < <(db_read_c --arg g "\$gn" '.users[]?|select(.group==\$g)')
        [[ -n "\$group_lines" ]] && msg+=\$'\n\n'"<i>\$(he "\$gn") → \$(he "\$out"):</i>\$group_lines"
    done < <(db_read_c '.user_groups[]?')
    [[ "\$has_any" -eq 0 ]] && msg+=\$'\n'"(无用户)"
    send "\$1" "\$msg"
}

cmd_link() {
    local cid="\$1" uname="\$2"
    [[ -z "\$uname" ]] && { send "\$cid" "用法: /link 用户名"; return; }
    local user node proto pw uuid_v effective_pw merged url
    user=\$(db_read_c --arg n "\$uname" '.users[]|select(.name==\$n)')
    [[ -z "\$user" ]] && { send "\$cid" "❌ 用户 \$(he "\$uname") 不存在"; return; }
    proto=\$(echo "\$user"|jq -r .protocol)
    pw=\$(echo "\$user"|jq -r '.password // empty')
    uuid_v=\$(echo "\$user"|jq -r '.uuid // empty')
    node=\$(db_read_c --arg t "\$proto" '.nodes[]|select(.type==\$t)')
    [[ -z "\$node" ]] && { send "\$cid" "❌ 节点不存在"; return; }
    # 修复 P0-G: SS-2022 多用户 URL 需要组合 serverPSK:userPSK
    effective_pw=\$(_effective_client_pw "\$node" "\$pw")
    merged=\$(echo "\$node" | jq --arg pw "\$effective_pw" --arg u "\$uuid_v" \\
        '.password = (if \$pw=="" then .password else \$pw end) | .uuid = (if \$u=="" then .uuid else \$u end)')
    if proto_has_url "\$proto"; then
        url=\$(proto_url "\$proto" "\$merged" "\$uname")
        send "\$cid" "<b>\$(he "\$uname")</b> [\$(he "\$proto")]
<code>\$(he "\$url")</code>"
    else
        send "\$cid" "❌ \$(he "\$proto") 协议不支持 URL 分享,请在 CLI 查看完整配置"
    fi
}

cmd_restart() { systemctl restart sing-box 2>/dev/null; send "\$1" "✅ sing-box 已重启"; }

cmd_security() {
    local f2b="停止" banned ssh_port pw_auth ufw_st
    systemctl is-active --quiet fail2ban 2>/dev/null && f2b="运行"
    banned=\$(fail2ban-client status sshd 2>/dev/null|grep "Currently banned"|awk '{print \$NF}' || echo "?")
    ssh_port=\$(grep "^Port" /etc/ssh/sshd_config 2>/dev/null|awk '{print \$2}' || echo "22")
    pw_auth=\$(grep "^PasswordAuthentication" /etc/ssh/sshd_config 2>/dev/null|awk '{print \$2}' || echo "yes")
    ufw_st=\$(ufw status 2>/dev/null|head -1 || echo "未安装")
    send "\$1" "<b>安全状态</b>
fail2ban: \$(he "\$f2b") (封禁: \$(he "\$banned")个IP)
SSH端口: \$(he "\$ssh_port")
密码登录: \$(he "\$pw_auth")
UFW: \$(he "\$ufw_st")"
}

cmd_ban() {
    local list; list=\$(fail2ban-client status sshd 2>/dev/null|grep "Banned IP"|sed 's/.*:\\s*//')
    [[ -z "\$list" || "\$list" == " " ]] && { send "\$1" "当前无封禁IP"; return; }
    send "\$1" "<b>封禁IP列表</b>
\$(he "\$list")
解封: /unban IP地址"
}

cmd_unban() {
    [[ -z "\$2" ]] && { send "\$1" "用法: /unban IP地址"; return; }
    fail2ban-client set sshd unbanip "\$2" 2>/dev/null \\
        && send "\$1" "✅ 已解封 \$(he "\$2")" || send "\$1" "❌ 解封失败"
}

cmd_ufw() {
    local rules; rules=\$(ufw status 2>/dev/null|grep -v "^\$"|head -20)
    [[ -z "\$rules" ]] && rules="UFW 未安装或未启用"
    send "\$1" "<b>UFW 规则</b>
<pre>\$(he "\$rules")</pre>"
}

cmd_help() {
    # 与 setMyCommands 保持一致(修复 P0-A)
    send "\$1" "<b>命令列表</b>
/status - 系统状态
/nodes - 节点列表
/users - 用户列表(按组)
/link 名 - 获取用户链接
/security - 安全状态(fail2ban/SSH/UFW)
/ban - 当前封禁 IP 列表
/unban IP - 解封 IP
/ufw - UFW 规则
/restart - 重启 sing-box
/help - 本帮助"
}

# 主循环
# 修复 P0-E: ALLOWED 必须立即初始化(SECONDS=0 时旧条件 (0-0>30) 永假,导致前 30s 拒绝所有消息)
ALLOWED=""
ALLOWED_REFRESH=0
while true; do
    # 周期性 reload .enabled / chat_ids,无需重启 bot
    # 启动期 ALLOWED 为空 → 立即初始化;之后每 30s 刷新一次
    if [[ -z "\$ALLOWED" ]] || (( SECONDS - ALLOWED_REFRESH > 30 )); then
        if ! is_enabled; then
            sleep 30; ALLOWED_REFRESH=\$SECONDS; continue
        fi
        ALLOWED=\$(db_read '.tgbot.chat_ids[]')
        ALLOWED_REFRESH=\$SECONDS
    fi

    RESP=\$(curl -s "https://api.telegram.org/bot\$BOT_TOKEN/getUpdates?offset=\$OFFSET&timeout=30&limit=10" 2>/dev/null)
    echo "\$RESP" | jq -e '.ok==true' >/dev/null 2>&1 || { sleep 5; continue; }

    while IFS= read -r update; do
        [[ -z "\$update" ]] && continue
        uid=\$(echo "\$update" | jq .update_id)
        cid=\$(echo "\$update" | jq '.message.chat.id // empty')
        txt=\$(echo "\$update" | jq -r '.message.text // empty')
        OFFSET=\$((uid+1))
        save_offset "\$OFFSET"
        [[ -z "\$cid" || -z "\$txt" ]] && continue
        echo "\$ALLOWED" | grep -q "^\${cid}\$" || continue

        cmd=\$(echo "\$txt" | awk '{print \$1}')
        a1=\$(echo "\$txt" | awk '{print \$2}')
        a2=\$(echo "\$txt" | awk '{print \$3}')
        case "\$cmd" in
            /start|/status) cmd_status "\$cid" ;;
            /nodes)         cmd_nodes "\$cid" ;;
            /users)         cmd_users "\$cid" ;;
            /link)          cmd_link "\$cid" "\$a1" ;;
            /restart)       cmd_restart "\$cid" ;;
            /security)      cmd_security "\$cid" ;;
            /ban)           cmd_ban "\$cid" ;;
            /unban)         cmd_unban "\$cid" "\$a1" ;;
            /ufw)           cmd_ufw "\$cid" ;;
            /help|*)        cmd_help "\$cid" ;;
        esac
        sleep 1
    done <<< "\$(echo "\$RESP" | jq -c '.result[]?' 2>/dev/null)"
done
TGEOF
    chmod +x "$TGBOT"
}

# 安全菜单
security_menu() {
    while true; do
        title "安全加固"
        info "当前 SSH 端口: $(sys_get_ssh_port)"
        echo "  1.开启 fail2ban  2.关闭 fail2ban  3.SSH 加固"
        echo "  4.开启 UFW       5.关闭 UFW       6.安全状态  0.返回"
        local c; read -rp "选择: " c
        case "$c" in
            1) f2b_install_and_configure ;;
            2) f2b_disable ;;
            3) sys_harden_ssh ;;
            4) ufw_enable ;;
            5) ufw_disable ;;
            6) sys_show_security ;;
            0) return ;;
        esac
        pause
    done
}

sys_show_security() {
    title "安全状态总览"
    if systemctl is-active --quiet fail2ban 2>/dev/null; then
        ok "fail2ban: 运行中"
        local banned; banned=$(fail2ban-client status sshd 2>/dev/null | grep "Currently banned" | awk '{print $NF}')
        info "  封禁IP: ${banned:-0} 个"
        info "  监控端口: $(grep "^port" /etc/fail2ban/jail.local 2>/dev/null | awk '{print $3}')"
    else
        warn "fail2ban: 未运行"
    fi
    local ssh_port pw_auth
    ssh_port=$(sys_get_ssh_port)
    pw_auth=$(grep "^PasswordAuthentication" /etc/ssh/sshd_config 2>/dev/null | awk '{print $2}')
    info "SSH 端口: $ssh_port"
    info "SSH 密码登录: ${pw_auth:-yes}"
    if command -v ufw &>/dev/null; then
        local ufw_st; ufw_st=$(ufw status 2>/dev/null | head -1)
        info "UFW: $ufw_st"
        ufw status 2>/dev/null | grep ALLOW | while read -r l; do info "  $l"; done
    else
        warn "UFW: 未安装"
    fi
}

# ═════════════════════════════════════════════════
# 主菜单
# ═════════════════════════════════════════════════

show_menu() {
    while true; do
        [[ -t 1 ]] && clear 2>/dev/null || true
        echo -e "${P}
╔═══════════════════════════════════════════════════╗
║       Sing-box 节点管理 v${VER}                    ║
╠═══════════════════════════════════════════════════╣
║  1. 节点管理  (搭建/查看/删除协议节点)            ║
║  2. 入站管理  (用户组/用户/分享链接)              ║
║  3. 出站管理  (导入/删除外部代理)                 ║
║  4. 路由规则  (用户组 → 出站)                     ║
║  5. 系统设置  (状态/TGBot/安全/BBR/更新)          ║
║  0. 退出                                          ║
╚═══════════════════════════════════════════════════╝${N}"
        read -rp "选择 [0-5]: " c
        case "$c" in
            1) node_menu ;;
            2) inbound_menu ;;
            3) outbound_menu ;;
            4) route_menu ;;
            5) sys_menu ;;
            0) info "再见!"; exit 0 ;;
            *) err "无效"; pause ;;
        esac
    done
}

main() {
    check_root
    check_sys
    # flock 是 DB 事务的硬依赖,必须存在
    command -v flock &>/dev/null || { err "缺少 flock 命令(Linux util-linux 包提供),请先安装"; exit 1; }
    mkdir -p "$(dirname "$LOG")" "$TGBOT_STATE_DIR"
    touch "$LOG" 2>/dev/null; chmod 600 "$LOG" 2>/dev/null
    log "启动 v$VER"
    db_init
    db_migrate
    [[ -f "$CFG/shortcut.conf" ]] || sys_install_shortcut "s" "$SCRIPT"
    sys_install_deps
    sys_install_singbox
    sys_setup_singbox_service
    if [[ -f "$SB" ]] && jq -e '.inbounds|length>0' "$SB" >/dev/null 2>&1; then
        systemctl is-active --quiet sing-box || systemctl start sing-box 2>/dev/null
    fi
    DOMAIN=$(get_domain); IP=$(get_ip)
    show_menu
}

# 只有作为可执行脚本直接运行时才进 main,被 source 时不进(用于测试 / TG bot 复用)
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
    main "$@"
fi
