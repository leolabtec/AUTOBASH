# shellcheck shell=bash
# lib/ufw.sh — 防火墙层
# 设计原则: 永不 reset,基于持久化的 managed-ports 清单做增量 diff
# 消掉: P0-3, A-6, P1-1, P1-5, 续签 hook 误删 80

[[ -n "${_SB_UFW_LOADED:-}" ]] && return 0
readonly _SB_UFW_LOADED=1

[[ -z "${_SB_COMMON_LOADED:-}" ]] && { echo "lib/ufw.sh 需要 lib/common.sh" >&2; return 1; }

# ─── managed-ports 持久化清单 ────────────────
# 结构: {"ports":[{"port":443,"proto":"tcp","tag":"trojan"},...], "temp":[...]}
# tag 用于追踪谁创建的(节点 type / "ssh" / "acme-80")
_ufw_managed_init() {
    [[ -f "$UFW_MANAGED" ]] && return 0
    mkdir -p "$(dirname "$UFW_MANAGED")"
    echo '{"ports":[],"temp":[]}' > "$UFW_MANAGED"
    chmod 600 "$UFW_MANAGED"
}

# 协议 → 需要放行的传输层
node_ufw_protos() {
    case "$1" in
        hysteria2|tuic) echo "udp" ;;
        shadowsocks)    echo "tcp udp" ;;
        *)              echo "tcp" ;;
    esac
}

# UFW 是否可用且 active
ufw_active() {
    command -v ufw &>/dev/null || return 1
    ufw status 2>/dev/null | grep -q "Status: active"
}

# ─── 增量操作:加单条 ────────────────────────
# ufw_add <port> <proto> <tag>
# 注: ufw allow/delete 即使 UFW inactive 也会持久化到 user.rules,enable 时自动生效。
#     因此无需 if ufw_active 守卫。
ufw_add() {
    local port="$1" proto="$2" tag="$3"
    command -v ufw &>/dev/null || return 0
    _ufw_managed_init
    # 写入 managed(允许重复 tag,但同 port+proto 去重)
    local tmp; tmp=$(mktemp "${UFW_MANAGED}.XXXXXX") || return 1
    jq --argjson p "$port" --arg pr "$proto" --arg t "$tag" \
        '.ports = ((.ports|map(select(.port!=$p or .proto!=$pr))) + [{port:$p,proto:$pr,tag:$t}])' \
        "$UFW_MANAGED" > "$tmp" && chmod 600 "$tmp" && mv "$tmp" "$UFW_MANAGED"

    ufw allow "$port/$proto" &>/dev/null \
        && info "UFW: 放行 $port/$proto ($tag)" \
        || warn "UFW: 放行 $port/$proto 失败"
}

# ufw_remove <port> <proto>
ufw_remove() {
    local port="$1" proto="$2"
    command -v ufw &>/dev/null || return 0
    _ufw_managed_init
    local tmp; tmp=$(mktemp "${UFW_MANAGED}.XXXXXX") || return 1
    jq --argjson p "$port" --arg pr "$proto" \
        '.ports = (.ports|map(select(.port!=$p or .proto!=$pr)))' \
        "$UFW_MANAGED" > "$tmp" && chmod 600 "$tmp" && mv "$tmp" "$UFW_MANAGED"

    ufw delete allow "$port/$proto" &>/dev/null \
        && info "UFW: 关闭 $port/$proto" || true
}

# ─── 同步:DB 节点 vs managed 做 diff ─────────
# 调用场景: 节点变更后,或开启 UFW 时
# 双向同步: 旧 managed - new = 需 ufw delete; new - 已 UFW 中 = 需 ufw allow
# 修复 P1: 删节点后 UFW stale 规则
ufw_sync_from_db() {
    _ufw_managed_init
    [[ -f "$DB" ]] || return 0
    local n type port proto

    # 1. 旧 managed 的脚本管理端口集合(用于 diff 出"需要删的")
    local old_managed; old_managed=$(jq -c '[.ports[]|select(.tag!="ssh")|{port,proto}]' "$UFW_MANAGED")

    # 2. 计算 DB 应有的端口集合
    local expected="[]"
    while IFS= read -r n; do
        [[ -z "$n" ]] && continue
        type=$(echo "$n" | jq -r .type)
        port=$(echo "$n" | jq -r .port)
        for proto in $(node_ufw_protos "$type"); do
            expected=$(echo "$expected" | jq --argjson p "$port" --arg pr "$proto" --arg t "$type" \
                '.+[{port:$p,proto:$pr,tag:$t}]')
        done
    done < <(jq -c '.nodes[]?' "$DB" 2>/dev/null)

    # 3. 写回 managed(保留 ssh tag 不动;节点 tag 全替换为 expected)
    local tmp; tmp=$(mktemp "${UFW_MANAGED}.XXXXXX") || return 1
    jq --argjson exp "$expected" \
        '.ports = ((.ports|map(select(.tag=="ssh"))) + $exp)' \
        "$UFW_MANAGED" > "$tmp" && chmod 600 "$tmp" && mv "$tmp" "$UFW_MANAGED"

    command -v ufw &>/dev/null || return 0

    # 4. 删除 stale 规则:在 old_managed 但不在 expected 的(port,proto)
    local to_remove; to_remove=$(jq -n --argjson old "$old_managed" --argjson new "$expected" \
        '[$old[] | . as $o | select([$new[]|{port,proto}] | index({port:$o.port,proto:$o.proto})|not)]')
    while IFS= read -r r; do
        [[ -z "$r" ]] && continue
        local rp=$(echo "$r" | jq -r .port) rpr=$(echo "$r" | jq -r .proto)
        ufw delete allow "$rp/$rpr" &>/dev/null && info "UFW: 移除 stale 端口 $rp/$rpr"
    done < <(echo "$to_remove" | jq -c '.[]')

    # 5. 增量加新规则(active/inactive 都执行;ufw 自带持久化)
    while IFS= read -r e; do
        [[ -z "$e" ]] && continue
        local p=$(echo "$e" | jq -r .port) pr=$(echo "$e" | jq -r .proto)
        ufw status 2>/dev/null | grep -qE "^${p}/${pr}\b|^${p}\b.*${pr}" \
            || ufw allow "$p/$pr" &>/dev/null
    done < <(jq -c '.ports[]' "$UFW_MANAGED")
}

# ─── 启用 UFW:增量构建,绝不 reset ────────────
# 修复 P0-3
ufw_enable() {
    command -v ufw &>/dev/null || { eval "$PKG ufw" &>/dev/null; }
    _ufw_managed_init

    local was_active=false
    ufw_active && was_active=true

    if [[ "$was_active" == "false" ]]; then
        # 首次启用:设默认策略(不动现有规则)
        ufw default deny incoming &>/dev/null
        ufw default allow outgoing &>/dev/null
    fi

    # 放行 SSH(从 sshd_config 读端口)
    local ssh_port
    ssh_port=$(grep "^Port" /etc/ssh/sshd_config 2>/dev/null | awk '{print $2}' | head -1)
    ssh_port="${ssh_port:-22}"
    ufw_add "$ssh_port" "tcp" "ssh"

    # 同步节点端口
    ufw_sync_from_db

    if [[ "$was_active" == "false" ]]; then
        ufw --force enable &>/dev/null
        ok "UFW 已启用(增量模式,未触碰手工规则)"
    else
        ok "UFW 端口已同步"
    fi
    ufw status numbered 2>/dev/null | head -30
}

ufw_disable() {
    if ufw_active; then
        ufw --force disable &>/dev/null
        ok "UFW 已关闭(规则保留)"
    else
        warn "UFW 未启用"
    fi
}

# ─── 临时端口(acme 80) ──────────────────────
# 修复 续签 hook 误删 80:用 marker 标记是否脚本临时加的
ufw_open_temp() {
    local port="$1" proto="${2:-tcp}" marker_id="$3"
    _ufw_managed_init
    # 已被手工放行的不动(匹配 "443/tcp" 行首,允许任意尾随空白)
    if ufw_active && ufw status 2>/dev/null | grep -qE "^[[:space:]]*${port}/${proto}([[:space:]]|$)"; then
        return 0   # 已开,不标记,续签 hook 也不会删
    fi
    local tmp; tmp=$(mktemp "${UFW_MANAGED}.XXXXXX") || return 1
    jq --argjson p "$port" --arg pr "$proto" --arg m "$marker_id" \
        '.temp += [{port:$p,proto:$pr,marker:$m}]' \
        "$UFW_MANAGED" > "$tmp" && chmod 600 "$tmp" && mv "$tmp" "$UFW_MANAGED"
    ufw_active && ufw allow "$port/$proto" &>/dev/null
}

ufw_close_temp() {
    local marker_id="$1"
    _ufw_managed_init
    # 查 marker 对应的 port/proto,只删脚本临时加的
    local rows
    rows=$(jq -c --arg m "$marker_id" '.temp[]|select(.marker==$m)' "$UFW_MANAGED")
    [[ -z "$rows" ]] && return 0
    while IFS= read -r r; do
        [[ -z "$r" ]] && continue
        local p=$(echo "$r" | jq -r .port) pr=$(echo "$r" | jq -r .proto)
        ufw_active && ufw delete allow "$p/$pr" &>/dev/null
    done <<< "$rows"
    local tmp; tmp=$(mktemp "${UFW_MANAGED}.XXXXXX") || return 1
    jq --arg m "$marker_id" '.temp = (.temp|map(select(.marker!=$m)))' \
        "$UFW_MANAGED" > "$tmp" && chmod 600 "$tmp" && mv "$tmp" "$UFW_MANAGED"
}

# ─── fail2ban 配置(带 banaction=ufw) ─────────
# 修复 P1-5
f2b_install_and_configure() {
    eval "$PKG fail2ban" &>/dev/null
    local ssh_port backend="auto" logpath=""
    ssh_port=$(grep "^Port" /etc/ssh/sshd_config 2>/dev/null | awk '{print $2}' | head -1)
    ssh_port="${ssh_port:-22}"

    if [[ -f /var/log/auth.log ]]; then
        backend="auto"; logpath="/var/log/auth.log"
    elif journalctl --no-pager -n1 &>/dev/null; then
        backend="systemd"
    fi

    local ba="iptables-multiport"
    ufw_active && ba="ufw"

    cat > /etc/fail2ban/jail.local <<EOF
[DEFAULT]
backend = $backend
banaction = $ba

[sshd]
enabled = true
port = $ssh_port
maxretry = 5
bantime = 1800
findtime = 600
$([ -n "$logpath" ] && echo "logpath = $logpath")
EOF
    systemctl enable fail2ban 2>/dev/null
    systemctl restart fail2ban 2>/dev/null
    sleep 2
    if systemctl is-active --quiet fail2ban && fail2ban-client status sshd &>/dev/null; then
        ok "fail2ban OK (端口:$ssh_port 后端:$backend banaction:$ba)"
        info "  5 次失败 → 封禁 30 分钟"
        return 0
    else
        err "fail2ban 启动失败"
        journalctl -u fail2ban -n 10 --no-pager
        return 1
    fi
}

f2b_disable() {
    if systemctl is-active --quiet fail2ban 2>/dev/null; then
        systemctl stop fail2ban 2>/dev/null
        systemctl disable fail2ban 2>/dev/null
        ok "fail2ban 已关闭"
    else
        warn "fail2ban 未运行"
    fi
}
