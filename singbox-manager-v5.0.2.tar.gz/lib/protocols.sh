# shellcheck shell=bash
# lib/protocols.sh — 协议层
# 设计原则: 每协议封装 build_inbound / render / parse_link 三元组,统一 UX 契约
# 消掉: A-1(端口冲突), AA-1(AnyTLS URL), L-1/Q-4(IPv6+URL 解码), 三-1(SS-2022 密钥长度)
# UX 契约: 节点信息 + URL(可空) + 二维码(URL 有则) + extras(协议特定附加)

[[ -n "${_SB_PROTO_LOADED:-}" ]] && return 0
readonly _SB_PROTO_LOADED=1

[[ -z "${_SB_COMMON_LOADED:-}" ]] && { echo "lib/protocols.sh 需要 lib/common.sh" >&2; return 1; }

# 可创建的协议清单(顺序即菜单顺序)
readonly PROTO_TYPES=(trojan vless-reality hysteria2 tuic shadowsocks snell shadowtls anytls)

# 协议显示名
proto_display_name() {
    case "$1" in
        trojan)        echo "Trojan" ;;
        vless-reality) echo "VLESS+Reality" ;;
        hysteria2)     echo "Hysteria2" ;;
        tuic)          echo "TUIC v5" ;;
        shadowsocks)   echo "Shadowsocks" ;;
        snell)         echo "Snell v5" ;;
        shadowtls)     echo "ShadowTLS v3" ;;
        anytls)        echo "AnyTLS" ;;
        *)             echo "$1" ;;
    esac
}

# 协议是否支持 URL 分享
proto_has_url() {
    case "$1" in
        trojan|vless-reality|hysteria2|tuic|shadowsocks|anytls) return 0 ;;
        *) return 1 ;;
    esac
}

# 协议是否支持多用户(节点凭证之外的 users[])
proto_supports_multiuser() {
    case "$1" in
        vless-reality|snell) return 1 ;;
        shadowsocks)
            local m
            m=$(db_read '.nodes[]?|select(.type=="shadowsocks")|.extra.method' | head -1)
            [[ "$m" == 2022-blake3-* ]]
            ;;
        *) return 0 ;;
    esac
}

# ═════════════════════════════════════════════
# A. URL 构造(返回空字符串则该协议不支持 URL)
# ═════════════════════════════════════════════
proto_url() {
    local type="$1" node="$2"
    local domain="${DOMAIN:-$(get_domain)}" ip="${IP:-$(get_ip)}"
    local port pw uuid extra label
    port=$(echo "$node" | jq -r '.port')
    pw=$(echo "$node"   | jq -r '.password // empty')
    uuid=$(echo "$node" | jq -r '.uuid // empty')
    extra=$(echo "$node"| jq -c '.extra // {}')
    label="${3:-$(proto_display_name "$type")}"

    case "$type" in
        trojan)
            echo "trojan://${pw}@${domain}:${port}?security=tls&sni=${domain}&type=tcp#${label}" ;;
        vless-reality)
            local pub sid sn
            pub=$(echo "$extra" | jq -r '.public_key')
            sid=$(echo "$extra" | jq -r '.short_id')
            sn=$(echo "$extra"  | jq -r '.server_name')
            echo "vless://${uuid}@${ip}:${port}?encryption=none&flow=xtls-rprx-vision&security=reality&sni=${sn}&fp=chrome&pbk=${pub}&sid=${sid}&type=tcp#${label}" ;;
        hysteria2)
            echo "hysteria2://${pw}@${domain}:${port}?sni=${domain}#${label}" ;;
        tuic)
            local cc; cc=$(echo "$extra" | jq -r '.congestion_control // "bbr"')
            echo "tuic://${uuid}:${pw}@${domain}:${port}?congestion_control=${cc}&sni=${domain}&alpn=h3#${label}" ;;
        shadowsocks)
            local m; m=$(echo "$extra" | jq -r '.method')
            local userinfo; userinfo=$(echo -n "${m}:${pw}" | base64 | tr '+/' '-_' | tr -d '=\n')
            echo "ss://${userinfo}@${ip}:${port}#${label}" ;;
        anytls)
            # 修复 AA-1: AnyTLS URL(clash.meta / mihomo 1.18+ 格式)
            echo "anytls://${pw}@${domain}:${port}?sni=${domain}&insecure=0#${label}" ;;
        *) echo "" ;;
    esac
}

# ═════════════════════════════════════════════
# B. 节点信息 + extras 渲染
# ═════════════════════════════════════════════
_print_qr() {
    local url="$1"
    command -v qrencode &>/dev/null || return 0
    qrencode -t ANSIUTF8 "$url" 2>/dev/null
}

_print_url_block() {
    local url="$1"
    [[ -z "$url" ]] && return 0
    echo
    echo -e "${Y}分享链接:${N}"
    echo "$url"
    echo
    _print_qr "$url"
}

# 渲染节点信息行(每协议自己 echo "  字段: 值")
_render_info_trojan() {
    local node="$1" domain="$2"
    local port pw
    port=$(echo "$node" | jq -r .port)
    pw=$(echo "$node"   | jq -r .password)
    cat <<EOF
  服务器: $domain
  端口:   $port
  密码:   $pw
  TLS:    开启
  SNI:    $domain
  传输:   TCP
EOF
}

_render_info_vless_reality() {
    local node="$1" ip="$2"
    local port uuid extra pub sid sn
    port=$(echo "$node"   | jq -r .port)
    uuid=$(echo "$node"   | jq -r .uuid)
    extra=$(echo "$node"  | jq -c '.extra')
    pub=$(echo "$extra"   | jq -r .public_key)
    sid=$(echo "$extra"   | jq -r .short_id)
    sn=$(echo "$extra"    | jq -r .server_name)
    cat <<EOF
  服务器:    $ip
  端口:      $port
  UUID:      $uuid
  Flow:      xtls-rprx-vision
  安全:      Reality
  伪装域名:  $sn
  PublicKey: $pub
  ShortID:   $sid
  指纹:      chrome
  传输:      TCP
EOF
}

_render_info_hysteria2() {
    local node="$1" domain="$2"
    local port pw
    port=$(echo "$node" | jq -r .port)
    pw=$(echo "$node"   | jq -r .password)
    cat <<EOF
  服务器: $domain
  端口:   $port (UDP)
  密码:   $pw
  TLS:    开启
  SNI:    $domain
EOF
}

_render_info_tuic() {
    local node="$1" domain="$2"
    local port uuid pw cc
    port=$(echo "$node" | jq -r .port)
    uuid=$(echo "$node" | jq -r .uuid)
    pw=$(echo "$node"   | jq -r .password)
    cc=$(echo "$node"   | jq -r '.extra.congestion_control // "bbr"')
    cat <<EOF
  服务器:   $domain
  端口:     $port (UDP)
  UUID:     $uuid
  密码:     $pw
  拥塞控制: $cc
  ALPN:     h3
  TLS:      开启
  SNI:      $domain
EOF
}

_render_info_shadowsocks() {
    local node="$1" ip="$2"
    local port pw m
    port=$(echo "$node" | jq -r .port)
    pw=$(echo "$node"   | jq -r .password)
    m=$(echo "$node"    | jq -r '.extra.method')
    cat <<EOF
  服务器: $ip
  端口:   $port
  加密:   $m
  密码:   $pw
EOF
}

_render_info_anytls() {
    local node="$1" domain="$2"
    local port pw
    port=$(echo "$node" | jq -r .port)
    pw=$(echo "$node"   | jq -r .password)
    cat <<EOF
  服务器: $domain
  端口:   $port
  密码:   $pw
  TLS:    开启
  SNI:    $domain
  Padding: 开启
EOF
}

_render_info_shadowtls() {
    local node="$1" ip="$2"
    local port stp sm sp hs
    port=$(echo "$node" | jq -r .port)
    stp=$(echo "$node"  | jq -r '.extra.stls_password')
    sm=$(echo "$node"   | jq -r '.extra.ss_method')
    sp=$(echo "$node"   | jq -r '.extra.ss_password')
    hs=$(echo "$node"   | jq -r '.extra.handshake_server')
    cat <<EOF
  服务器:        $ip
  端口:          $port
  ShadowTLS密码: $stp
  SS加密:        $sm
  SS密码:        $sp
  握手伪装:      $hs
  版本:          3
EOF
}

_render_info_snell() {
    local node="$1" ip="$2"
    local port pw ob
    port=$(echo "$node" | jq -r .port)
    pw=$(echo "$node"   | jq -r .password)
    ob=$(echo "$node"   | jq -r '.extra.obfs // "http"')
    cat <<EOF
  服务器: $ip
  端口:   $port
  PSK:    $pw
  混淆:   $ob
  版本:   5
EOF
}

# extras: 协议特定的客户端配置示例(只有少数协议有)
_render_extras_shadowtls() {
    local node="$1" ip="$2"
    local port stp sm sp hs
    port=$(echo "$node" | jq -r .port)
    stp=$(echo "$node"  | jq -r '.extra.stls_password')
    sm=$(echo "$node"   | jq -r '.extra.ss_method')
    sp=$(echo "$node"   | jq -r '.extra.ss_password')
    hs=$(echo "$node"   | jq -r '.extra.handshake_server')
    echo
    echo -e "${Y}sing-box 客户端 outbounds 示例:${N}"
    jq -n --arg s "$ip" --argjson p "$port" --arg stp "$stp" --arg hs "$hs" --arg sm "$sm" --arg sp "$sp" '[
        {type:"shadowsocks",tag:"proxy",server:"127.0.0.1",server_port:0,method:$sm,password:$sp,detour:"shadowtls-out"},
        {type:"shadowtls",tag:"shadowtls-out",server:$s,server_port:$p,version:3,password:$stp,tls:{enabled:true,server_name:$hs}}
    ]'
}

_render_extras_snell() {
    local node="$1" ip="$2"
    local port pw ob
    port=$(echo "$node" | jq -r .port)
    pw=$(echo "$node"   | jq -r .password)
    ob=$(echo "$node"   | jq -r '.extra.obfs // "http"')
    echo
    echo -e "${Y}Surge 配置:${N}"
    echo "  Snell = snell, $ip, $port, psk=$pw, version=5, obfs=$ob"
}

# ═════════════════════════════════════════════
# C. 统一渲染入口
# ═════════════════════════════════════════════
# render_node <type> [label]
#   从 DB 读节点,按统一契约打印: 信息 + URL + 二维码 + extras
render_node() {
    local type="$1" label="${2:-}"
    local node; node=$(db_read_c --arg t "$type" '.nodes[]|select(.type==$t)')
    [[ -z "$node" ]] && { warn "节点 $type 不存在"; return 1; }
    local domain="${DOMAIN:-$(get_domain)}" ip="${IP:-$(get_ip)}"

    sep
    echo -e "${W}$(proto_display_name "$type") 节点详情${N}"

    case "$type" in
        trojan)        _render_info_trojan "$node" "$domain" ;;
        vless-reality) _render_info_vless_reality "$node" "$ip" ;;
        hysteria2)     _render_info_hysteria2 "$node" "$domain" ;;
        tuic)          _render_info_tuic "$node" "$domain" ;;
        shadowsocks)   _render_info_shadowsocks "$node" "$ip" ;;
        anytls)        _render_info_anytls "$node" "$domain" ;;
        shadowtls)     _render_info_shadowtls "$node" "$ip"
                       echo
                       echo -e "  ${Y}注意: ShadowTLS 需要客户端支持 (sing-box/clash.meta)${N}" ;;
        snell)         _render_info_snell "$node" "$ip" ;;
    esac

    if proto_has_url "$type"; then
        local url; url=$(proto_url "$type" "$node" "$label")
        _print_url_block "$url"
    fi

    case "$type" in
        shadowtls) _render_extras_shadowtls "$node" "$ip" ;;
        snell)     _render_extras_snell "$node" "$ip" ;;
    esac
    sep
}

# SS-2022 多用户客户端密码 = serverPSK:userPSK (base64 拼后 sing-box 解出来用)
# 给定 node + user_pw,返回客户端应该用的实际 password 字符串
# 修复 P0-G: 多用户 SS-2022 之前只渲染 userPSK,客户端缺 serverPSK 无法连接
_effective_client_pw() {
    local node="$1" user_pw="$2"
    local node_type node_pw method
    node_type=$(echo "$node" | jq -r .type)
    if [[ "$node_type" == "shadowsocks" && -n "$user_pw" ]]; then
        method=$(echo "$node" | jq -r '.extra.method // ""')
        if [[ "$method" == 2022-blake3-* ]]; then
            node_pw=$(echo "$node" | jq -r '.password // ""')
            echo "${node_pw}:${user_pw}"
            return
        fi
    fi
    echo "$user_pw"
}

# 用户视角:用 user.name 作为 label,简化输出
render_user() {
    local uname="$1"
    local user; user=$(db_read_c --arg n "$uname" '.users[]|select(.name==$n)')
    [[ -z "$user" ]] && { warn "用户 $uname 不存在"; return 1; }
    local proto grp
    proto=$(echo "$user" | jq -r .protocol)
    grp=$(echo "$user"   | jq -r '.group // "无"')

    # 复制节点信息,但用 user 的凭证覆盖
    local node; node=$(db_read_c --arg t "$proto" '.nodes[]|select(.type==$t)')
    [[ -z "$node" ]] && { warn "节点 $proto 不存在"; return 1; }
    local user_pw user_uuid effective_pw merged
    user_pw=$(echo "$user"   | jq -r '.password // empty')
    user_uuid=$(echo "$user" | jq -r '.uuid // empty')
    # 修复 P0-G: SS-2022 多用户场景需要组合 serverPSK:userPSK,其他协议直接用 user_pw
    effective_pw=$(_effective_client_pw "$node" "$user_pw")
    merged=$(echo "$node" | jq --arg pw "$effective_pw" --arg u "$user_uuid" \
        '.password = (if $pw=="" then .password else $pw end) | .uuid = (if $u=="" then .uuid else $u end)')

    # 查路由出站(展示用)
    local route_out="direct"
    if [[ "$grp" != "无" && -n "$grp" ]]; then
        route_out=$(db_read --arg g "$grp" '.routes[]?|select(.group==$g)|.outbound') || true
        [[ -z "$route_out" ]] && route_out="direct"
    fi

    sep
    echo -e "${W}用户: $uname${N}    [协议:$proto  组:$grp  出站:$route_out]"
    local domain="${DOMAIN:-$(get_domain)}" ip="${IP:-$(get_ip)}"
    case "$proto" in
        trojan)        _render_info_trojan "$merged" "$domain" ;;
        hysteria2)     _render_info_hysteria2 "$merged" "$domain" ;;
        tuic)          _render_info_tuic "$merged" "$domain" ;;
        shadowsocks)   _render_info_shadowsocks "$merged" "$ip" ;;
        anytls)        _render_info_anytls "$merged" "$domain" ;;
        shadowtls)     _render_info_shadowtls "$merged" "$ip" ;;
    esac
    if proto_has_url "$proto"; then
        local url; url=$(proto_url "$proto" "$merged" "$uname")
        _print_url_block "$url"
    fi
    sep
}

# ═════════════════════════════════════════════
# D. sing-box inbound 生成
# ═════════════════════════════════════════════
# proto_build_inbound <type> <node-json> → stdout: inbounds JSON 数组
# 多用户合并: 节点凭证 + DB.users 该协议的用户
_users_for_proto() {
    local type="$1"
    db_read_c --arg t "$type" '[.users[]|select(.protocol==$t)]'
}

proto_build_inbound() {
    local type="$1" node="$2"
    local port pw uuid extra
    port=$(echo "$node"  | jq -r .port)
    pw=$(echo "$node"    | jq -r '.password // empty')
    uuid=$(echo "$node"  | jq -r '.uuid // empty')
    extra=$(echo "$node" | jq -c '.extra // {}')
    local users; users=$(_users_for_proto "$type")

    case "$type" in
        trojan)
            local u_arr; u_arr=$(jq -n --arg pw "$pw" --argjson us "$users" \
                '[{name:"owner",password:$pw}] + [$us[]|{name:.name,password:.password}]')
            jq -n --argjson p "$port" --argjson us "$u_arr" --arg c "$CERT/fullchain.pem" --arg k "$CERT/private.pem" \
                '[{type:"trojan",tag:"trojan-in",listen:"::",listen_port:$p,users:$us,tls:{enabled:true,certificate_path:$c,key_path:$k},fallback:{server:"127.0.0.1",server_port:8080}}]'
            ;;
        vless-reality)
            local pk sn sid
            pk=$(echo "$extra"  | jq -r .private_key)
            sn=$(echo "$extra"  | jq -r .server_name)
            sid=$(echo "$extra" | jq -r .short_id)
            jq -n --argjson p "$port" --arg u "$uuid" --arg pk "$pk" --arg sn "$sn" --arg sid "$sid" \
                '[{type:"vless",tag:"vless-reality-in",listen:"::",listen_port:$p,users:[{uuid:$u,flow:"xtls-rprx-vision"}],tls:{enabled:true,server_name:$sn,reality:{enabled:true,handshake:{server:$sn,server_port:443},private_key:$pk,short_id:[$sid]}}}]'
            ;;
        hysteria2)
            local u_arr; u_arr=$(jq -n --arg pw "$pw" --argjson us "$users" \
                '[{name:"owner",password:$pw}] + [$us[]|{name:.name,password:.password}]')
            jq -n --argjson p "$port" --argjson us "$u_arr" --arg c "$CERT/fullchain.pem" --arg k "$CERT/private.pem" \
                '[{type:"hysteria2",tag:"hysteria2-in",listen:"::",listen_port:$p,users:$us,tls:{enabled:true,certificate_path:$c,key_path:$k}}]'
            ;;
        tuic)
            local cc; cc=$(echo "$extra" | jq -r '.congestion_control // "bbr"')
            local u_arr; u_arr=$(jq -n --arg u "$uuid" --arg pw "$pw" --argjson us "$users" \
                '[{name:"owner",uuid:$u,password:$pw}] + [$us[]|{name:.name,uuid:.uuid,password:.password}]')
            jq -n --argjson p "$port" --argjson us "$u_arr" --arg cc "$cc" --arg c "$CERT/fullchain.pem" --arg k "$CERT/private.pem" \
                '[{type:"tuic",tag:"tuic-in",listen:"::",listen_port:$p,users:$us,congestion_control:$cc,tls:{enabled:true,certificate_path:$c,key_path:$k,alpn:["h3"]}}]'
            ;;
        shadowsocks)
            local m; m=$(echo "$extra" | jq -r '.method // "2022-blake3-aes-128-gcm"')
            local u_cnt; u_cnt=$(echo "$users" | jq 'length // 0')
            if [[ "$m" == 2022-blake3-* && "$u_cnt" -gt 0 ]]; then
                jq -n --argjson p "$port" --arg pw "$pw" --arg m "$m" --argjson us "$users" \
                    '[{type:"shadowsocks",tag:"ss-in",listen:"::",listen_port:$p,method:$m,password:$pw,users:[$us[]|{name:.name,password:.password}]}]'
            else
                jq -n --argjson p "$port" --arg pw "$pw" --arg m "$m" \
                    '[{type:"shadowsocks",tag:"ss-in",listen:"::",listen_port:$p,method:$m,password:$pw}]'
            fi
            ;;
        shadowtls)
            local hs sm sp stp
            hs=$(echo "$extra"  | jq -r .handshake_server)
            sm=$(echo "$extra"  | jq -r .ss_method)
            sp=$(echo "$extra"  | jq -r .ss_password)
            stp=$(echo "$extra" | jq -r .stls_password)
            local u_arr; u_arr=$(jq -n --arg pw "$stp" --argjson us "$users" \
                '[{name:"owner",password:$pw}] + [$us[]|{name:.name,password:.password}]')
            # 修复 P1-3: 内层 SS 显式 listen_port: 0(由 detour 接管)
            jq -n --argjson p "$port" --argjson us "$u_arr" --arg hs "$hs" --arg sm "$sm" --arg sp "$sp" \
                '[
                    {type:"shadowtls",tag:"shadowtls-in",listen:"::",listen_port:$p,version:3,users:$us,handshake:{server:$hs,server_port:443},strict_mode:true,detour:"shadowtls-ss-in"},
                    {type:"shadowsocks",tag:"shadowtls-ss-in",listen:"127.0.0.1",listen_port:0,method:$sm,password:$sp}
                ]'
            ;;
        anytls)
            local u_arr; u_arr=$(jq -n --arg pw "$pw" --argjson us "$users" \
                '[{name:"owner",password:$pw}] + [$us[]|{name:.name,password:.password}]')
            jq -n --argjson p "$port" --argjson us "$u_arr" --arg c "$CERT/fullchain.pem" --arg k "$CERT/private.pem" \
                '[{type:"anytls",tag:"anytls-in",listen:"::",listen_port:$p,users:$us,tls:{enabled:true,certificate_path:$c,key_path:$k}}]'
            ;;
        snell) echo "[]" ;;   # snell 是独立服务,不在 sing-box 配置内
        *) echo "[]" ;;
    esac
}

# ═════════════════════════════════════════════
# E. 主配置生成:遍历所有节点 + 出站 + 路由
# ═════════════════════════════════════════════
# gen_config — 生成完整 sing-box config.json,带原子写 + 备份回滚
# 修复 A-2-b: 通过 tmp + rename 避免半写
gen_config() {
    info "生成配置..."
    mkdir -p "$CFG"
    local tmp_cfg; tmp_cfg=$(mktemp) || return 1
    local bak="${SB}.bak"
    [[ -f "$SB" ]] && cp -p "$SB" "$bak"

    # 1. inbounds: 遍历所有节点
    local inbounds="[]"
    local node ibs
    while IFS= read -r node; do
        [[ -z "$node" ]] && continue
        local t; t=$(echo "$node" | jq -r .type)
        ibs=$(proto_build_inbound "$t" "$node")
        [[ "$ibs" == "[]" ]] && continue
        inbounds=$(echo "$inbounds" | jq --argjson new "$ibs" '. + $new')
    done < <(db_read_c '.nodes[]?')

    # 2. outbounds: direct + DB.outbounds
    local outbounds; outbounds=$(db_read_c '
        [{type:"direct",tag:"direct"}] +
        [.outbounds[]? |
            {type,tag,server,server_port} +
            (if .username and .username!="" then {username,password} else {} end) +
            (if .type=="shadowsocks" then {method,password} elif .password and .password!="" then {password} else {} end) +
            (if .tls and .tls.enabled==true then {tls} else {} end)
        ]') || outbounds='[{"type":"direct","tag":"direct"}]'

    # 3. route: 用户组 → 出站
    local route_json="null"
    local has_routes; has_routes=$(db_read '.routes | length // 0')
    if [[ "$has_routes" -gt 0 ]]; then
        local rules; rules=$(db_read_c '
            [.routes[] as $r |
                ([.users[]?|select(.group==$r.group)|.name]) as $names |
                if ($names|length)>0 then {auth_user:$names,action:"route",outbound:$r.outbound} else empty end
            ]')
        local rcnt; rcnt=$(echo "$rules" | jq 'length // 0')
        [[ "$rcnt" -gt 0 ]] && route_json=$(jq -n --argjson r "$rules" '{rules:$r,final:"direct"}')
    fi

    # 4. 组装
    if [[ "$route_json" == "null" ]]; then
        jq -n --argjson ib "$inbounds" --argjson ob "$outbounds" \
            '{log:{disabled:true},inbounds:$ib,outbounds:$ob}' > "$tmp_cfg"
    else
        jq -n --argjson ib "$inbounds" --argjson ob "$outbounds" --argjson rt "$route_json" \
            '{log:{disabled:true},inbounds:$ib,outbounds:$ob,route:$rt}' > "$tmp_cfg"
    fi

    # 5. sing-box check
    if sing-box check -c "$tmp_cfg" >/dev/null 2>&1; then
        mv "$tmp_cfg" "$SB"
        chmod 600 "$SB"
        rm -f "$bak"
        ok "配置 OK"
        return 0
    else
        err "配置错误:"
        sing-box check -c "$tmp_cfg" 2>&1 | tail -5
        rm -f "$tmp_cfg" "$bak"
        return 1
    fi
}

# 端口冲突预检:DB.nodes 里同 (port,proto) 出现 >1 次?
# 修复 §3.1: sing-box check 不检测端口冲突,启动时才报 bind: address already in use
# 在 sb_validate 这里挡住,确保 db_update strict 路径有防御深度
_port_conflict_check() {
    local dup
    dup=$(db_read_c '
        [.nodes[]|{
            port,
            type,
            protos: (
                if .type=="hysteria2" or .type=="tuic" then ["udp"]
                elif .type=="shadowsocks" then ["tcp","udp"]
                elif .type=="snell" then []
                else ["tcp"] end
            )
        }]
        | [.[] | . as $n | $n.protos[] | {port:$n.port, proto:., type:$n.type}]
        | group_by({port,proto})
        | map(select(length>1))
    ')
    if [[ -n "$dup" && "$dup" != "[]" ]]; then
        err "端口冲突: $(echo "$dup" | jq -c '.[][]|{type,port,proto}')"
        return 1
    fi
    return 0
}

# sb_validate — 给 lib/db.sh 的 db_update strict 模式回调
# 双重防御: 1) DB 层端口冲突预检 2) sing-box schema 校验
sb_validate() {
    _port_conflict_check || return 1
    gen_config >/dev/null 2>&1
}

# ═════════════════════════════════════════════
# F. 解析导入链接(SS/SOCKS/HTTP)
# ═════════════════════════════════════════════
# 修复 L-1 + Q-4: URL decode + IPv6 host:port

parse_link() {
    local link="$1"
    case "$link" in
        ss://*)                  _parse_ss     "$link" ;;
        socks5://*|socks://*)    _parse_socks  "$link" ;;
        http://*@*|https://*@*)  _parse_http   "$link" ;;
        *) return 1 ;;
    esac
}

# 共用:从 "host:port" 切出 host/port(IPv6 安全)
_split_hp() { split_host_port "$1"; }

# 共用:tag 命名,避免冲突
_make_tag() {
    local prefix="$1" host="$2" port="$3"
    local sanitized; sanitized=$(echo "$host" | tr '.:' '__')
    local tag="${prefix}-${sanitized}"
    db_exists --arg t "$tag" '.outbounds[]|select(.tag==$t)' && tag="${tag}_${port}"
    echo "$tag"
}

_parse_ss() {
    local body="${1#ss://}"; body="${body%%#*}"
    local m p s po
    if [[ "$body" == *"@"* ]]; then
        local ui="${body%%@*}" hp="${body##*@}"
        hp="${hp%%\?*}"; hp="${hp%%/*}"
        local decoded
        decoded=$(echo -n "$ui" | base64 -d 2>/dev/null \
               || echo -n "${ui}="  | base64 -d 2>/dev/null \
               || echo -n "${ui}==" | base64 -d 2>/dev/null)
        m="${decoded%%:*}"; p="${decoded#*:}"
        read -r s po <<< "$(_split_hp "$hp")"
    else
        local decoded
        decoded=$(echo -n "$body" | base64 -d 2>/dev/null \
               || echo -n "${body}=" | base64 -d 2>/dev/null)
        m="${decoded%%:*}"; local r="${decoded#*:}"
        p="${r%%@*}"; local hp="${r##*@}"
        read -r s po <<< "$(_split_hp "$hp")"
    fi
    po="${po//[!0-9]/}"
    [[ -z "$s" || -z "$po" ]] && return 1
    local tag; tag=$(_make_tag "ss" "$s" "$po")
    jq -n --arg t "$tag" --arg s "$s" --argjson p "$po" --arg m "$m" --arg pw "$p" \
        '{type:"shadowsocks",tag:$t,server:$s,server_port:$p,method:$m,password:$pw}'
}

_parse_socks() {
    local body="${1#socks5://}"; body="${body#socks://}"; body="${body%%#*}"
    body="${body%%\?*}"; body="${body%%/*}"
    local u="" pw="" s po
    if [[ "$body" == *"@"* ]]; then
        local ui="${body%%@*}" hp="${body##*@}"
        u=$(urldecode "${ui%%:*}")
        pw=$(urldecode "${ui#*:}")
        read -r s po <<< "$(_split_hp "$hp")"
    else
        read -r s po <<< "$(_split_hp "$body")"
    fi
    po="${po//[!0-9]/}"
    [[ -z "$s" || -z "$po" ]] && return 1
    local tag; tag=$(_make_tag "socks" "$s" "$po")
    if [[ -n "$u" ]]; then
        jq -n --arg t "$tag" --arg s "$s" --argjson p "$po" --arg u "$u" --arg pw "$pw" \
            '{type:"socks",tag:$t,server:$s,server_port:$p,username:$u,password:$pw}'
    else
        jq -n --arg t "$tag" --arg s "$s" --argjson p "$po" \
            '{type:"socks",tag:$t,server:$s,server_port:$p}'
    fi
}

_parse_http() {
    local uri="$1" tls=false
    [[ "$uri" == https://* ]] && tls=true
    local body="${uri#https://}"; body="${body#http://}"; body="${body%%#*}"
    body="${body%%\?*}"; body="${body%%/*}"
    local u="" pw="" s po
    if [[ "$body" == *"@"* ]]; then
        local ui="${body%%@*}" hp="${body##*@}"
        u=$(urldecode "${ui%%:*}")
        pw=$(urldecode "${ui#*:}")
        read -r s po <<< "$(_split_hp "$hp")"
    else
        read -r s po <<< "$(_split_hp "$body")"
    fi
    po="${po//[!0-9]/}"
    [[ -z "$s" || -z "$po" ]] && return 1
    local tag; tag=$(_make_tag "http" "$s" "$po")
    local base
    if [[ -n "$u" ]]; then
        base=$(jq -n --arg t "$tag" --arg s "$s" --argjson p "$po" --arg u "$u" --arg pw "$pw" \
            '{type:"http",tag:$t,server:$s,server_port:$p,username:$u,password:$pw}')
    else
        base=$(jq -n --arg t "$tag" --arg s "$s" --argjson p "$po" \
            '{type:"http",tag:$t,server:$s,server_port:$p}')
    fi
    [[ "$tls" == "true" ]] && echo "$base" | jq '. + {tls:{enabled:true}}' || echo "$base"
}

# ═════════════════════════════════════════════
# G. 出站连通性测试
# ═════════════════════════════════════════════
test_outbound() {
    local ob="$1"
    local type s p
    type=$(echo "$ob" | jq -r .type)
    s=$(echo "$ob"    | jq -r .server)
    p=$(echo "$ob"    | jq -r .server_port)
    case "$type" in
        socks)
            local px="socks5://"
            local u; u=$(echo "$ob" | jq -r '.username // empty')
            [[ -n "$u" ]] && px+="$u:$(echo "$ob" | jq -r .password)@"
            px+="$s:$p"
            curl -x "$px" -s --max-time 8 -o /dev/null -w "%{http_code}" "http://httpbin.org/ip" 2>/dev/null | grep -q "200"
            ;;
        http)
            local px="http://"
            local u; u=$(echo "$ob" | jq -r '.username // empty')
            [[ -n "$u" ]] && px+="$u:$(echo "$ob" | jq -r .password)@"
            px+="$s:$p"
            curl -x "$px" -s --max-time 8 -o /dev/null -w "%{http_code}" "http://httpbin.org/ip" 2>/dev/null | grep -q "200"
            ;;
        shadowsocks)
            local tp=$((RANDOM % 10000 + 40000))
            local cfg; cfg=$(jq -n --argjson p "$tp" --argjson ob "$ob" \
                '{log:{disabled:true},inbounds:[{type:"socks",tag:"t",listen:"127.0.0.1",listen_port:$p}],outbounds:[$ob+{tag:"o"}],route:{final:"o"}}')
            local tf; tf=$(mktemp); echo "$cfg" > "$tf"; chmod 600 "$tf"
            sing-box check -c "$tf" >/dev/null 2>&1 || { rm -f "$tf"; return 1; }
            sing-box run -c "$tf" &>/dev/null & local pid=$!
            local i=0; while [[ $i -lt 10 ]]; do
                ss -tln 2>/dev/null | grep -q ":${tp} " && break; sleep 0.5; ((i++)) || true
            done
            local rc=1
            curl -x "socks5://127.0.0.1:${tp}" -s --max-time 8 -o /dev/null -w "%{http_code}" "http://httpbin.org/ip" 2>/dev/null | grep -q "200" && rc=0
            kill "$pid" 2>/dev/null; wait "$pid" 2>/dev/null || true
            rm -f "$tf"
            return $rc
            ;;
        *) return 0 ;;
    esac
}
