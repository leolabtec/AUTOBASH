# shellcheck shell=bash
# lib/system.sh — 系统层
# 负责: 依赖安装、systemd 服务、SSH 加固、证书、BBR、伪装站、TG bot 生命周期
# 消掉: Q-1, Q-2, X-1, P1-6(dig 缺依赖), 续签 hook 误删 80

[[ -n "${_SB_SYS_LOADED:-}" ]] && return 0
readonly _SB_SYS_LOADED=1

[[ -z "${_SB_COMMON_LOADED:-}" ]] && { echo "lib/system.sh 需要 lib/common.sh" >&2; return 1; }

# ═════════════════════════════════════════════
# A. 依赖
# ═════════════════════════════════════════════
sys_install_deps() {
    info "检查依赖..."
    local need=() bin
    for p in curl wget jq openssl qrencode socat cron unzip python3 dig; do
        bin="$p"
        case "$p" in
            cron) bin="crontab" ;;
            dig)  bin="dig" ;;
        esac
        command -v "$bin" &>/dev/null || need+=("$p")
    done
    [[ ${#need[@]} -eq 0 ]] && { ok "依赖就绪"; return 0; }

    # 把 dig 映射到包名
    local pkgs=()
    for p in "${need[@]}"; do
        case "$p" in
            dig)
                case "$ID" in
                    debian|ubuntu|linuxmint) pkgs+=("dnsutils") ;;
                    *)                       pkgs+=("bind-utils") ;;
                esac
                ;;
            *) pkgs+=("$p") ;;
        esac
    done

    info "安装: ${pkgs[*]}"
    [[ "$ID" == debian || "$ID" == ubuntu ]] && apt update -qq &>/dev/null
    eval "$PKG ${pkgs[*]}" &>/dev/null
    ok "依赖就绪"
}

# ═════════════════════════════════════════════
# B. sing-box 安装/服务
# ═════════════════════════════════════════════
sys_install_singbox() {
    command -v sing-box &>/dev/null && return 0
    info "安装 sing-box..."
    bash <(curl -fsSL https://sing-box.app/deb-install.sh) 2>/dev/null || {
        local v a
        v=$(curl -s https://api.github.com/repos/SagerNet/sing-box/releases/latest | jq -r .tag_name | sed 's/v//')
        a=$(uname -m); [[ "$a" == "x86_64" ]] && a="amd64" || a="arm64"
        rm -rf /tmp/sing-box-* /tmp/sb.tar.gz
        curl -fsSL "https://github.com/SagerNet/sing-box/releases/download/v${v}/sing-box-${v}-linux-${a}.tar.gz" -o /tmp/sb.tar.gz
        mkdir -p /tmp/sb-extract && tar -xzf /tmp/sb.tar.gz -C /tmp/sb-extract/
        cp /tmp/sb-extract/sing-box-*/sing-box /usr/local/bin/sing-box || { err "安装失败"; return 1; }
        chmod +x /usr/local/bin/sing-box
        rm -rf /tmp/sb* /tmp/sing-box-*
    }
    ok "$(sing-box version 2>/dev/null | head -1)"
}

# 修复 X-1: ExecStart 用 /usr/bin/env,不固化二进制路径
sys_setup_singbox_service() {
    [[ -f "$SB" ]] || { mkdir -p "$CFG"; echo '{"log":{"disabled":true},"inbounds":[],"outbounds":[{"type":"direct","tag":"direct"}]}' > "$SB"; }
    if systemctl list-unit-files sing-box.service &>/dev/null 2>&1; then
        mkdir -p /etc/systemd/system/sing-box.service.d
        cat > /etc/systemd/system/sing-box.service.d/override.conf <<EOF
[Service]
ExecStart=
ExecStart=/usr/bin/env sing-box run -c $SB
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
AmbientCapabilities=CAP_NET_BIND_SERVICE
EOF
        systemctl daemon-reload
        systemctl enable sing-box 2>/dev/null
        return 0
    fi
    [[ -f /etc/systemd/system/sing-box.service ]] && return 0
    cat > /etc/systemd/system/sing-box.service <<EOF
[Unit]
Description=sing-box
After=network.target

[Service]
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
AmbientCapabilities=CAP_NET_BIND_SERVICE
ExecStart=/usr/bin/env sing-box run -c $SB
Restart=on-failure
RestartSec=10s
LimitNOFILE=infinity

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    systemctl enable sing-box 2>/dev/null
}

sys_restart_singbox() {
    info "重启 sing-box..."
    systemctl restart sing-box
    sleep 2
    if systemctl is-active --quiet sing-box; then
        ok "sing-box 运行中"
        return 0
    else
        err "sing-box 启动失败"
        journalctl -u sing-box -n 10 --no-pager
        return 1
    fi
}

# 升级 sing-box(带 tarball 残留清理 + 版本校验)
# 修复 L-3: 解压前清理 + cp 失败立即返回 + 版本号比对
sys_update_singbox() {
    local sb_bin cur latest
    sb_bin=$(command -v sing-box || echo "/usr/local/bin/sing-box")
    cur=$(sing-box version 2>/dev/null | head -1 | grep -oP '\d+\.\d+\.\d+' || echo "?")
    latest=$(curl -s https://api.github.com/repos/SagerNet/sing-box/releases/latest | jq -r .tag_name | sed 's/v//')
    info "当前: $cur  最新: $latest"
    [[ "$cur" == "$latest" ]] && { ok "已是最新"; return 0; }

    local cur_major="${cur%%.*}" lat_major="${latest%%.*}"
    [[ "$cur_major" != "$lat_major" && "$cur_major" != "?" ]] \
        && warn "大版本升级 ($cur_major→$lat_major),配置格式可能不兼容!"
    confirm "更新到 $latest?" || return 0

    local a; a=$(uname -m); [[ "$a" == "x86_64" ]] && a="amd64" || a="arm64"
    cp "$sb_bin" "${sb_bin}.bak" 2>/dev/null
    info "已备份旧版本: ${sb_bin}.bak"
    systemctl stop sing-box

    rm -rf /tmp/sb-extract /tmp/sb.tar.gz
    if ! curl -fsSL "https://github.com/SagerNet/sing-box/releases/download/v${latest}/sing-box-${latest}-linux-${a}.tar.gz" -o /tmp/sb.tar.gz; then
        err "下载失败"
        systemctl start sing-box
        return 1
    fi
    mkdir -p /tmp/sb-extract
    if ! tar -xzf /tmp/sb.tar.gz -C /tmp/sb-extract/; then
        err "解压失败"
        rm -rf /tmp/sb-extract /tmp/sb.tar.gz
        systemctl start sing-box
        return 1
    fi
    if ! cp /tmp/sb-extract/sing-box-*/sing-box "$sb_bin"; then
        err "拷贝二进制失败,旧版本保留"
        rm -rf /tmp/sb-extract /tmp/sb.tar.gz
        systemctl start sing-box
        return 1
    fi
    chmod +x "$sb_bin"
    rm -rf /tmp/sb-extract /tmp/sb.tar.gz

    # 校验:版本号必须对得上
    local installed; installed=$(sing-box version 2>/dev/null | head -1 | grep -oP '\d+\.\d+\.\d+' || echo "?")
    if [[ "$installed" != "$latest" ]]; then
        err "安装后版本($installed) ≠ 期望($latest),回退"
        cp "${sb_bin}.bak" "$sb_bin" 2>/dev/null
        systemctl start sing-box
        return 1
    fi

    if sing-box check -c "$SB" >/dev/null 2>&1; then
        systemctl start sing-box; sleep 2
        if systemctl is-active --quiet sing-box; then
            ok "更新成功: $(sing-box version | head -1)"
            rm -f "${sb_bin}.bak"
            return 0
        else
            err "新版本启动失败,回退到 $cur"
            cp "${sb_bin}.bak" "$sb_bin" 2>/dev/null
            systemctl start sing-box
            journalctl -u sing-box -n 5 --no-pager
            return 1
        fi
    else
        err "新版本配置验证失败,回退到 $cur"
        sing-box check -c "$SB" 2>&1 | tail -3
        cp "${sb_bin}.bak" "$sb_bin" 2>/dev/null
        systemctl start sing-box
        return 1
    fi
}

# ═════════════════════════════════════════════
# C. 证书(acme.sh)
# ═════════════════════════════════════════════
# 修复 A-7: 显示剩余天数 + 加配额警告;修复续签 hook 误删 80
sys_issue_cert() {
    unset SUDO_USER SUDO_COMMAND SUDO_UID SUDO_GID 2>/dev/null || true
    title "证书管理"
    if [[ -f "$CERT/fullchain.pem" ]]; then
        local cur_d; cur_d=$(get_domain)
        local end_d; end_d=$(openssl x509 -in "$CERT/fullchain.pem" -noout -enddate 2>/dev/null | sed 's/notAfter=//')
        local end_ts now_ts days
        end_ts=$(date -d "$end_d" +%s 2>/dev/null || echo 0)
        now_ts=$(date +%s)
        days=$(( (end_ts - now_ts) / 86400 ))
        info "当前: $cur_d  到期: $end_d  剩余: ${days} 天"
        if [[ $days -gt 30 ]]; then
            warn "证书还有 ${days} 天才到期,强制重签会消耗 Let's Encrypt 每周配额 (5 次/周)"
            confirm "确定要强制重签?" || return 0
        else
            confirm "续签证书?" || return 0
        fi
    fi
    [[ -f "$ACME" ]] || { info "安装 acme.sh..."; curl -fsSL https://get.acme.sh | sh 2>/dev/null || return 1; }
    "$ACME" --set-default-ca --server letsencrypt 2>/dev/null || true
    local d; read -rp "域名: " d
    [[ -z "$d" ]] && return 0
    mkdir -p "$CERT"

    # DNS 解析校验
    local resolved my_ip
    resolved=$(dig +short "$d" A @8.8.8.8 2>/dev/null | head -1)
    my_ip=$(get_ip)
    if [[ -n "$resolved" && "$resolved" != "$my_ip" ]]; then
        warn "域名 $d 解析到 $resolved,本机 IP 是 $my_ip"
        confirm "继续?" || return 0
    fi

    # 80 端口占用检查
    if ss -tln 2>/dev/null | grep -q ":80 "; then
        err "80 端口被占用,先停止占用进程: $(ss -tlnp 2>/dev/null | grep ':80 ' | head -1)"
        return 1
    fi

    # 临时放行 80(带 marker,只有脚本临时开的才会被 post-hook 删)
    local marker="acme-issue-$$"
    if command -v ufw_open_temp &>/dev/null; then
        ufw_open_temp 80 tcp "$marker"
    fi

    info "签发证书..."
    local hook_pre="echo acme-renew-$d > /var/lib/singbox-manager/acme-renew-marker && ufw allow 80/tcp 2>/dev/null || true"
    local hook_post="[ -f /var/lib/singbox-manager/acme-renew-marker ] && ufw delete allow 80/tcp 2>/dev/null && rm -f /var/lib/singbox-manager/acme-renew-marker || true"
    mkdir -p /var/lib/singbox-manager

    local acme_out acme_rc=1
    acme_out=$("$ACME" --issue -d "$d" --standalone --keylength ec-256 --force \
        --pre-hook "$hook_pre" --post-hook "$hook_post" 2>&1) && acme_rc=0 || acme_rc=$?
    echo "$acme_out" | tail -5

    if [[ $acme_rc -eq 0 ]]; then
        "$ACME" --install-cert -d "$d" --ecc \
            --fullchain-file "$CERT/fullchain.pem" --key-file "$CERT/private.pem" \
            --reloadcmd "systemctl restart sing-box 2>/dev/null || true" 2>&1 | tail -2 || true
        chmod 644 "$CERT/fullchain.pem" 2>/dev/null
        chmod 600 "$CERT/private.pem"   2>/dev/null
        if [[ -s "$CERT/fullchain.pem" ]]; then
            DOMAIN="$d"
            ok "证书 OK: $d"
        else
            err "证书安装失败(文件为空)"
        fi
    else
        err "签发失败 (退出码: $acme_rc)"
        echo "$acme_out" | grep -iE "error|invalid|fail|denied|timeout|firewall" | tail -3
        info "常见原因: DNS 未指向本机、80 端口被防火墙阻止、频率限制"
    fi

    # 关闭临时 80
    command -v ufw_close_temp &>/dev/null && ufw_close_temp "$marker"
}

# ═════════════════════════════════════════════
# D. BBR
# ═════════════════════════════════════════════
sys_enable_bbr() {
    local cc; cc=$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null)
    if [[ "$cc" == "bbr" ]]; then
        ok "BBR 已启用"
        return 0
    fi
    modprobe tcp_bbr 2>/dev/null
    cat > /etc/sysctl.d/99-bbr.conf <<EOF
net.core.default_qdisc=fq
net.ipv4.tcp_congestion_control=bbr
EOF
    sysctl -p /etc/sysctl.d/99-bbr.conf &>/dev/null
    ok "BBR 已启用"
}

# ═════════════════════════════════════════════
# E. 伪装站(nginx-light + 静态 HTML)
# ═════════════════════════════════════════════
# 为什么用 nginx 不用 python http.server:
#  - python3 -m http.server 在 Server header 暴露 "SimpleHTTP/0.6 Python/3.11.2",GFW 主动探测立刻识别为代理
#  - nginx-light Server header = "nginx/1.x.x",全球 ~30% 真实网站标配,无破绽
#  - 内存:nginx-light ~8MB(master+1 worker)< python http.server ~15MB
#  - 维护:apt unattended-upgrades 自动跟安全补丁
sys_setup_fakeweb() {
    # 装 nginx-light(最轻量,无 PHP/Lua/SSL 模块,~600KB 包)
    if ! command -v nginx &>/dev/null; then
        info "安装 nginx-light..."
        eval "$PKG nginx-light" &>/dev/null
    fi

    mkdir -p "$FAKEWEB"
    cat > "$FAKEWEB/index.html" <<'HTML'
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>CloudTech</title><style>body{font-family:system-ui;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;background:#f8f9fa}.c{text-align:center}h1{color:#667eea}p{color:#666}</style></head><body><div class="c"><h1>CloudTech Solutions</h1><p>Enterprise cloud infrastructure</p></div></body></html>
HTML

    # 写一个独立的 fakeweb server block,监听 127.0.0.1:8080
    # 不动 nginx 默认 site,免得干扰用户其他用途
    mkdir -p /etc/nginx/conf.d
    cat > /etc/nginx/conf.d/fakeweb.conf <<EOF
server {
    listen 127.0.0.1:8080 default_server;
    server_name _;
    root $FAKEWEB;
    index index.html;
    server_tokens off;       # 不暴露 nginx 小版本号(只显示 "nginx")
    access_log off;          # fakeweb 是 fallback,不必记访问日志
    location / {
        try_files \$uri \$uri/ =404;
    }
}
EOF

    # 关掉 nginx 默认 site 监听的 80 端口(避免和 acme.sh standalone 续签冲突)
    # 两种发行版风格都处理:Debian/Ubuntu (sites-enabled/default) + RHEL/upstream (conf.d/default.conf)
    [[ -f /etc/nginx/sites-enabled/default ]] && rm -f /etc/nginx/sites-enabled/default
    [[ -f /etc/nginx/conf.d/default.conf ]] && rm -f /etc/nginx/conf.d/default.conf

    # 清理旧的 python fakeweb 服务(从老版本升级时)
    if [[ -f /etc/systemd/system/fakeweb.service ]]; then
        systemctl disable --now fakeweb 2>/dev/null
        rm -f /etc/systemd/system/fakeweb.service
        systemctl daemon-reload
    fi

    # 校验 nginx 配置并启动
    if nginx -t &>/dev/null; then
        systemctl enable nginx 2>/dev/null
        systemctl reload nginx 2>/dev/null || systemctl restart nginx
        ok "fakeweb (nginx) 已就绪,监听 127.0.0.1:8080"
    else
        err "nginx 配置校验失败:"
        nginx -t 2>&1 | tail -3
        return 1
    fi
}

# ═════════════════════════════════════════════
# F. Snell 独立服务
# ═════════════════════════════════════════════
sys_setup_snell_service() {
    cat > /etc/systemd/system/snell.service <<EOF
[Unit]
Description=Snell
After=network.target

[Service]
ExecStart=$SNELL_BIN -c $SNELL_CFG
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    systemctl enable snell 2>/dev/null
}

sys_stop_snell() {
    systemctl is-active --quiet snell 2>/dev/null && systemctl stop snell 2>/dev/null
    systemctl is-enabled --quiet snell 2>/dev/null && systemctl disable snell 2>/dev/null
}

# ═════════════════════════════════════════════
# G. SSH 加固(含 authorized_keys 校验)
# ═════════════════════════════════════════════
sys_get_ssh_port() {
    local p; p=$(grep "^Port" /etc/ssh/sshd_config 2>/dev/null | awk '{print $2}' | head -1)
    echo "${p:-22}"
}

# 修复 Q-2: 禁用密码登录前必须存在 authorized_keys
sys_has_authorized_keys() {
    local key_files=(/root/.ssh/authorized_keys)
    [[ -n "${SUDO_USER:-}" ]] && key_files+=("/home/$SUDO_USER/.ssh/authorized_keys")
    local kf
    for kf in "${key_files[@]}"; do
        [[ -s "$kf" ]] && return 0
    done
    return 1
}

sys_harden_ssh() {
    local conf="/etc/ssh/sshd_config"
    local old_port; old_port=$(sys_get_ssh_port)
    info "当前 SSH 端口: $old_port"

    local new_port=""
    read -rp "新 SSH 端口(回车不改): " new_port
    if [[ -n "$new_port" && "$new_port" =~ ^[0-9]+$ ]]; then
        if ss -tln 2>/dev/null | grep -q ":${new_port} "; then
            err "端口 $new_port 已被占用"
            return 1
        fi
        if grep -q "^Port " "$conf"; then
            sed -i "s/^Port .*/Port $new_port/" "$conf"
        elif grep -q "^#Port " "$conf"; then
            sed -i "s/^#Port .*/Port $new_port/" "$conf"
        else
            echo "Port $new_port" >> "$conf"
        fi
        info "SSH 端口: $old_port → $new_port"
        if command -v ufw_add &>/dev/null && ufw_active; then
            ufw_add "$new_port" tcp "ssh"
            ufw_remove "$old_port" tcp
            info "UFW: 已放行 $new_port,移除 $old_port"
        fi
        if [[ -f /etc/fail2ban/jail.local ]]; then
            sed -i "s/^port = .*/port = $new_port/" /etc/fail2ban/jail.local
            systemctl restart fail2ban 2>/dev/null
            info "fail2ban: 已更新端口"
        fi
    fi

    # 关键:禁用密码前校验 authorized_keys
    if confirm "禁用密码登录?"; then
        if sys_has_authorized_keys; then
            sed -i 's/^#*PasswordAuthentication .*/PasswordAuthentication no/' "$conf"
            sed -i 's/^#*PubkeyAuthentication .*/PubkeyAuthentication yes/' "$conf"
            info "密码登录: 已禁用"
        else
            err "未找到 authorized_keys,拒绝禁用密码登录(会锁死 SSH)"
            warn "请先 ssh-copy-id 或手动写入 ~/.ssh/authorized_keys 后重试"
        fi
    fi

    sed -i 's/^#*PermitRootLogin .*/PermitRootLogin prohibit-password/' "$conf"

    if sshd -t 2>/dev/null; then
        systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null
        ok "SSH 配置已更新"
        [[ -n "$new_port" ]] && warn "请立即用新端口 $new_port 测试连接,确认后再关闭当前会话!"
    else
        err "SSH 配置有误,未重启"
        sshd -t
    fi
}

# ═════════════════════════════════════════════
# H. TG bot 生命周期
# ═════════════════════════════════════════════
# 修复 Q-1: stop + disable + .enabled 真正生效
sys_tgbot_stop() {
    systemctl is-active --quiet singbox-tgbot 2>/dev/null && systemctl stop singbox-tgbot 2>/dev/null
    systemctl is-enabled --quiet singbox-tgbot 2>/dev/null && systemctl disable singbox-tgbot 2>/dev/null
    db_update '.tgbot.enabled = false' 0
    ok "TG bot 已停止并禁用(下次重启不会自动起来)"
}

sys_tgbot_start() {
    db_update '.tgbot.enabled = true' 0
    systemctl enable singbox-tgbot 2>/dev/null
    systemctl restart singbox-tgbot
    ok "TG bot 已启动"
}

sys_tgbot_restart() {
    systemctl restart singbox-tgbot
    ok "TG bot 已重启"
}

# ═════════════════════════════════════════════
# I. 快捷键
# ═════════════════════════════════════════════
sys_install_shortcut() {
    local k="$1" script_path="$2"
    [[ -z "$k" ]] && return 1
    echo "$k" > "$CFG/shortcut.conf"
    local rc
    for rc in /root/.bashrc /root/.zshrc; do
        [[ -f "$rc" ]] || continue
        sed -i "\|alias ${k}=.*singbox-manager|d" "$rc"
        echo "alias ${k}='bash $script_path'" >> "$rc"
    done
    if [[ -n "${SUDO_USER:-}" ]]; then
        for rc in "/home/$SUDO_USER/.bashrc" "/home/$SUDO_USER/.zshrc"; do
            [[ -f "$rc" ]] || continue
            sed -i "\|alias ${k}=.*singbox-manager|d" "$rc"
            echo "alias ${k}='bash $script_path'" >> "$rc"
        done
    fi
    ok "快捷键: $k"
}
