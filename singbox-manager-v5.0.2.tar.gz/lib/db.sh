# shellcheck shell=bash
# lib/db.sh — 数据层
# 设计原则: 所有写入路径必须经过 db_update,自动加锁 + 校验 + 失败回滚
# 消掉: P0-1, P0-2, P0-4, A-4, Q-3, A-3(备份命名)

[[ -n "${_SB_DB_LOADED:-}" ]] && return 0
readonly _SB_DB_LOADED=1

[[ -z "${_SB_COMMON_LOADED:-}" ]] && { echo "lib/db.sh 需要先 source lib/common.sh" >&2; return 1; }

# ─── 初始化 ────────────────────────────────────
db_init() {
    mkdir -p "$CFG" "$(dirname "$DB_LOCK")"
    if [[ ! -f "$DB" ]]; then
        echo '{"version":3,"nodes":[],"user_groups":[],"users":[],"outbounds":[],"routes":[],"tgbot":{"enabled":false,"bot_token":"","chat_ids":[]}}' > "$DB"
        chmod 600 "$DB"
    fi
    touch "$DB_LOCK" 2>/dev/null || true
}

# ─── 版本迁移(带时间戳备份) ──────────────────
# 修复 A-3: 备份名带时间戳避免覆盖
# 修复 跨文件系统 mv: tmp 文件放在 DB 同目录
db_migrate() {
    [[ -f "$DB" ]] || return 0
    jq -e '.version==3' "$DB" >/dev/null 2>&1 && return 0
    local ts; ts=$(date +%Y%m%d-%H%M%S)
    if jq -e '.version==2' "$DB" >/dev/null 2>&1; then
        info "迁移 v2→v3..."
        cp "$DB" "${DB}.v2-${ts}.bak"
        local tmp; tmp=$(mktemp "${DB}.XXXXXX") || return 1
        if jq '{version:3,nodes:[.inbounds[]|{type,port,password:(.password//""),uuid:(.uuid//""),extra:(.extra//{})}],user_groups:[],users:[],outbounds:.outbounds,routes:[],tgbot:(.tgbot // {enabled:false,bot_token:"",chat_ids:[]})}' "$DB" > "$tmp" 2>/dev/null && jq -e '.version==3 and (.nodes|type=="array")' "$tmp" >/dev/null 2>&1; then
            chmod 600 "$tmp"; mv "$tmp" "$DB"; ok "迁移完成 (备份: ${DB}.v2-${ts}.bak)"
        else
            rm -f "$tmp"; err "迁移失败,DB 保持不变"; return 1
        fi
        return 0
    fi
    if jq -e '.nodes and (.version|not)' "$DB" >/dev/null 2>&1; then
        info "迁移 v1→v3..."
        cp "$DB" "${DB}.v1-${ts}.bak"
        local tmp; tmp=$(mktemp "${DB}.XXXXXX") || return 1
        if jq '{version:3,nodes:[.nodes[]|{type,port:(.port//0),password:(.password//""),uuid:(.uuid//""),extra:(.extra//{})}],user_groups:[],users:[],outbounds:[],routes:[],tgbot:{enabled:false,bot_token:"",chat_ids:[]}}' "$DB" > "$tmp" 2>/dev/null && jq -e '.version==3 and (.nodes|type=="array")' "$tmp" >/dev/null 2>&1; then
            chmod 600 "$tmp"; mv "$tmp" "$DB"; ok "迁移完成 (备份: ${DB}.v1-${ts}.bak)"
        else
            rm -f "$tmp"; err "迁移失败,DB 保持不变"; return 1
        fi
    fi
}

# ─── 只读查询 ────────────────────────────────
# db_read <jq-filter>          → stdout
# db_exists <jq-filter>        → exit 0/1
db_read()   { jq -r "$@" "$DB" 2>/dev/null; }
db_read_c() { jq -c "$@" "$DB" 2>/dev/null; }
db_exists() { jq -e "$@" "$DB" >/dev/null 2>&1; }

# ─── 核心:事务化写入 ─────────────────────────
# db_update <jq-filter> [check_singbox]
#   - subshell flock 加锁,串行所有写入(避免嵌套调用时 exec 9> 提前释放外层锁)
#   - jq 执行 filter,产物必须是合法 JSON
#   - 通过则原子 rename;否则清理 tmp 并 return 1
#   - check_singbox=1 时,落盘后调 sb_validate(由 protocols.sh 提供),失败回滚
#   - 全程 trap 保护,即使被 kill 也能完成回滚或清理
# 修复: P0-2 / P0-4 / Q-3 / 跨文件系统 mv / 进程中断时 DB 残留无效状态
# 签名: db_update [--arg|--argjson k v]... <filter> [check_singbox]
# 调用方传任意数量 jq --arg / --argjson,然后 filter,最后可选 check_singbox(0|1,默认0)
# 设计选择:把 jq args 放在前面,filter 紧跟最后的 1/0(或缺省),便于读写
db_update() {
    # 收集 jq args(成对的 --arg|--argjson k v),直到遇到 filter
    local -a jq_args=()
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --arg|--argjson)
                jq_args+=("$1" "$2" "$3")
                shift 3
                ;;
            *) break ;;
        esac
    done
    local filter="$1" check_singbox="${2:-0}"
    [[ -z "$filter" ]] && { err "db_update: 缺 filter 参数"; return 1; }

    (
        flock -x -w 10 200 || { err "DB 锁等待超时"; exit 1; }

        # tmp 文件放在 DB 同目录,避免跨文件系统 mv 退化为 cp+rm
        local tmp bak
        tmp=$(mktemp "${DB}.tmp.XXXXXX") || exit 1
        bak="${DB}.txn-$$.bak"

        # trap: 任何异常都清理 tmp,并尝试从 bak 恢复 DB
        cleanup_failed() {
            rm -f "$tmp"
            [[ -f "$bak" && ! -s "$DB" ]] && mv "$bak" "$DB"
            rm -f "$bak"
        }
        trap cleanup_failed EXIT INT TERM

        # 1. 备份当前 DB
        cp -p "$DB" "$bak" 2>/dev/null || exit 1

        # 2. 执行 jq filter(带可选 jq args)
        if ! jq "${jq_args[@]}" "$filter" "$DB" > "$tmp" 2>/dev/null; then
            err "jq filter 失败"
            exit 1
        fi

        # 3. 校验产物是合法 JSON 且非空对象
        if ! jq -e 'type=="object"' "$tmp" >/dev/null 2>&1; then
            err "jq 产物非合法 JSON object"
            exit 1
        fi

        # 4. 原子替换(chmod 在 mv 前做,避免短暂权限窗口)
        chmod 600 "$tmp"
        mv "$tmp" "$DB"

        # 5. 可选:sing-box 配置校验
        if [[ "$check_singbox" == "1" ]] && command -v sb_validate &>/dev/null; then
            if ! sb_validate; then
                warn "sing-box 配置校验失败,回滚 DB"
                mv "$bak" "$DB"; chmod 600 "$DB"
                exit 1
            fi
        fi

        # 成功:取消 trap,清理 bak
        trap - EXIT INT TERM
        rm -f "$bak"
        exit 0
    ) 200>"$DB_LOCK"
}

# ─── 简化别名:无 sing-box 校验的纯 DB 写入 ───
db_set()        { db_update "$1" 0; }
db_set_strict() { db_update "$1" 1; }   # 落盘后 + sing-box check
