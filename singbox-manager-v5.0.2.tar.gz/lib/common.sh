# shellcheck shell=bash
# lib/common.sh — 常量、颜色、日志、通用工具
# 设计原则: 无副作用,所有函数纯逻辑,不读写 DB/UFW/systemd

# 防重复 source
[[ -n "${_SB_COMMON_LOADED:-}" ]] && return 0
readonly _SB_COMMON_LOADED=1

# ─── 路径常量 ────────────────────────────────────
readonly CFG="${CFG:-/etc/sing-box}"
readonly SB="${SB:-$CFG/config.json}"
readonly DB="${DB:-$CFG/nodes.json}"
readonly CERT="${CERT:-/root/cert}"
readonly ACME="${ACME:-${HOME:-/root}/.acme.sh/acme.sh}"
readonly SNELL_BIN="${SNELL_BIN:-/usr/local/bin/snell-server}"
readonly SNELL_CFG="${SNELL_CFG:-/etc/snell/snell-server.conf}"
readonly TGBOT="${TGBOT:-/usr/local/bin/singbox-tgbot.sh}"
readonly FAKEWEB="${FAKEWEB:-/var/www/fakeweb}"
readonly LOG="${LOG:-/var/log/singbox-manager.log}"
readonly DB_LOCK="${DB_LOCK:-/var/lock/singbox-manager.lock}"
readonly UFW_MANAGED="${UFW_MANAGED:-$CFG/ufw-managed.json}"
readonly TGBOT_STATE_DIR="${TGBOT_STATE_DIR:-/var/lib/singbox-tgbot}"

# ─── 颜色 ────────────────────────────────────
readonly R='\033[0;31m' G='\033[0;32m' Y='\033[1;33m' B='\033[0;34m'
readonly P='\033[0;35m' C='\033[0;36m' W='\033[1;37m' N='\033[0m'

# ─── 日志/输出 ────────────────────────────────
log()   { echo "[$(date '+%F %T')] $*" >> "$LOG" 2>/dev/null || true; }
info()  { echo -e "${C}[INFO] $*${N}"; }
ok()    { echo -e "${G}[✓] $*${N}"; }
warn()  { echo -e "${Y}[!] $*${N}"; }
err()   { echo -e "${R}[✗] $*${N}"; }
sep()   { echo -e "${B}═══════════════════════════════════════════════════${N}"; }
title() { sep; echo -e "${W}    $*${N}"; sep; }

# ─── 交互 ────────────────────────────────────
confirm() { local a; read -rp "$(echo -e "${Y}${1:-确认?} [y/N]: ${N}")" a; [[ "$a" =~ ^[Yy]$ ]]; }
pause()   { echo; read -rp "按任意键..." -n1; echo; }

# ─── 凭证生成 ────────────────────────────────
# gp [length]    生成 alphanumeric 密码,默认 24 字符
# 修复 G-2: 源 entropy 至少 2 倍请求长度,保证去掉特殊字符后仍足够
gp() {
    local len="${1:-24}"
    local src_bytes=$((len * 2))
    [[ $src_bytes -lt 32 ]] && src_bytes=32
    openssl rand -base64 "$src_bytes" | tr -dc 'A-Za-z0-9' | head -c "$len"
}

gu() {
    command -v sing-box &>/dev/null && sing-box generate uuid || cat /proc/sys/kernel/random/uuid
}

# SS-2022 密钥按 method 决定字节长度(再 base64)
# 修复 三-1: blake3-128=16 字节, blake3-256=32 字节, 传统方法不调用此函数
gp_ss_key() {
    local method="$1"
    case "$method" in
        2022-blake3-aes-128-gcm) openssl rand -base64 16 ;;
        2022-blake3-aes-256-gcm) openssl rand -base64 32 ;;
        2022-blake3-chacha20-poly1305) openssl rand -base64 32 ;;
        *) openssl rand -base64 16 ;;
    esac
}

# ─── 网络/证书 ────────────────────────────────
get_ip() {
    curl -4 -s --max-time 5 https://api.ipify.org 2>/dev/null \
        || curl -4 -s --max-time 5 https://ifconfig.me 2>/dev/null
}

get_domain() {
    [[ -f "$CERT/fullchain.pem" ]] || { echo ""; return; }
    openssl x509 -in "$CERT/fullchain.pem" -noout -subject 2>/dev/null \
        | sed -nE 's/.*CN ?= ?([^,]*).*/\1/p'
}

# ─── host:port 切分(IPv6 安全) ────────────────
# 修复 L-1 / Q-4: 正确处理 [v6]:port 与 v4:port
# 用法: split_host_port "host[:port]" → 输出 "host port"
split_host_port() {
    local hp="$1" s po
    if [[ "$hp" == \[*\]* ]]; then
        s="${hp%%\]*}"; s="${s#\[}"
        local rest="${hp#*\]}"
        po="${rest#:}"
    else
        s="${hp%%:*}"
        po="${hp##*:}"
        [[ "$s" == "$po" ]] && po=""
    fi
    echo "$s $po"
}

# URL percent-decode(纯 bash,无外部依赖)
# 修复 L-1: parse_socks/parse_http 不做 URL 解码
urldecode() {
    local s="${1//+/ }"
    printf '%b' "${s//%/\\x}"
}

# ─── 端口工具 ────────────────────────────────
# 检查端口是否被占用(排除 sing-box 自身,且检查 DB 是否已登记)
# 修复 A-1: 节点 DB 中已登记的端口也算占用
port_free() {
    local p="$1" proto="${2:-both}"
    local in_use=1
    case "$proto" in
        tcp)  ss -tlnp 2>/dev/null  | grep ":${p} " | grep -qv sing-box && in_use=0 ;;
        udp)  ss -ulnp 2>/dev/null  | grep ":${p} " | grep -qv sing-box && in_use=0 ;;
        *)    ss -tulnp 2>/dev/null | grep ":${p} " | grep -qv sing-box && in_use=0 ;;
    esac
    [[ $in_use -eq 0 ]] && return 1
    # DB 内已登记同端口?
    if [[ -f "$DB" ]]; then
        jq -e --argjson p "$p" '.nodes[]?|select(.port==$p)' "$DB" >/dev/null 2>&1 && return 1
    fi
    return 0
}

rand_port() {
    local proto="${1:-both}" p
    for _ in {1..100}; do
        p=$((RANDOM % 50000 + 10000))
        port_free "$p" "$proto" && { echo "$p"; return 0; }
    done
    return 1
}

# 端口选择(交互):推荐 + 校验占用 + 校验 DB 重复
read_port() {
    local prompt="${1:-端口}" proto="${2:-both}" suggested
    suggested=$(rand_port "$proto")
    while true; do
        if [[ -n "$suggested" ]]; then
            echo -e "  ${C}推荐端口: $suggested (随机生成, 未占用)${N}"
            read -rp "$prompt [回车使用$suggested / 手动输入]: " REPLY_PORT
            REPLY_PORT="${REPLY_PORT:-$suggested}"
        else
            read -rp "$prompt: " REPLY_PORT
        fi
        [[ "$REPLY_PORT" =~ ^[0-9]+$ && "$REPLY_PORT" -ge 1 && "$REPLY_PORT" -le 65535 ]] \
            || { err "无效端口 (1-65535)"; continue; }
        if port_free "$REPLY_PORT" "$proto"; then
            ok "端口 $REPLY_PORT 可用"
            return 0
        else
            err "端口 $REPLY_PORT 已被占用 ($proto) 或 DB 已登记"
            suggested=$(rand_port "$proto")
        fi
    done
}

# ─── 系统检测 ────────────────────────────────
check_root() { [[ $EUID -eq 0 ]] || { err "需要 root"; exit 1; }; }

check_sys() {
    [[ -f /etc/os-release ]] || { err "未知系统"; exit 1; }
    . /etc/os-release
    case "$ID" in
        debian|ubuntu|linuxmint) PKG="apt install -y -qq" ;;
        centos|rhel|rocky|almalinux|fedora)
            command -v dnf &>/dev/null && PKG="dnf install -y -q" || PKG="yum install -y -q" ;;
        *) err "不支持 $ID"; exit 1 ;;
    esac
    export PKG ID
}
